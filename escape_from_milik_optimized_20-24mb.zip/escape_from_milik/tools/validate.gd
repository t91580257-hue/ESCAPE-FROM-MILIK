extends SceneTree
## Headless validation: parse-check all scripts and scenes.

var _fail := 0

func _init() -> void:
	var paths: Array[String] = []
	_collect("res://scripts", paths)
	var scenes: Array[String] = []
	_collect_scenes("res://scenes", scenes)
	for p in paths:
		var res: Variant = ResourceLoader.load(p, "", ResourceLoader.CACHE_MODE_REUSE)
		if res == null:
			printerr("PARSE FAIL: ", p)
			_fail += 1
	for p in scenes:
		var ps: Variant = ResourceLoader.load(p, "", ResourceLoader.CACHE_MODE_REUSE)
		if ps == null:
			printerr("SCENE FAIL: ", p)
			_fail += 1
	print("PARSE CHECK: ", paths.size(), " scripts, ", scenes.size(), " scenes, fails=", _fail)
	quit(1 if _fail > 0 else 0)


func _collect(dir_path: String, out: Array[String]) -> void:
	var dir := DirAccess.open(dir_path)
	if dir == null:
		return
	dir.list_dir_begin()
	var f := dir.get_next()
	while f != "":
		var full := dir_path + "/" + f
		if dir.current_is_dir():
			if not f.begins_with("."):
				_collect(full, out)
		elif f.ends_with(".gd"):
			out.append(full)
		f = dir.get_next()


func _collect_scenes(dir_path: String, out: Array[String]) -> void:
	var dir := DirAccess.open(dir_path)
	if dir == null:
		return
	dir.list_dir_begin()
	var f := dir.get_next()
	while f != "":
		var full := dir_path + "/" + f
		if dir.current_is_dir():
			if not f.begins_with("."):
				_collect_scenes(full, out)
		elif f.ends_with(".tscn"):
			out.append(full)
		f = dir.get_next()
