extends Node
## Headless smoke test — runs as a scene WITH autoloads.

var fails := 0


func _ready() -> void:
	call_deferred("_run")


func _run() -> void:
	# --- localization ---
	var loc: Node = Localization
	loc.language = "ru"
	_check(loc.tr_key("game.title") == "УБЕГИ ОТ МИЛИКА", "loc ru title")
	loc.language = "en"
	_check(loc.tr_key("menu.new_game") == "NEW GAME", "loc en")
	loc.language = "ru"
	var fmt: String = loc.tr_key("world.cage_need_gears") % [2, 3]
	_check(fmt == "Не хватает шестерёнок: 2 из 3.", "loc format")
	var missing := 0
	for k in ["hud.run", "hud.crouch", "world.cage_no_power", "objective.fix_cage",
			"puzzle.breaker_solved", "note.6.text", "diff.nightmare.desc", "set.ultra"]:
		if not loc.STRINGS.has(k):
			printerr("missing key: ", k)
			missing += 1
	_check(missing == 0, "loc keys")

	# --- difficulty ---
	var diff: Node = DifficultyManager
	for d in ["easy", "normal", "hard", "nightmare"]:
		diff.set_difficulty(d)
		var spd: Variant = diff.param("monster_speed_chase")
		_check(typeof(spd) == TYPE_FLOAT and spd > 1.0, "diff " + d)
	diff.set_difficulty("nightmare")
	_check(diff.param("respawn_to_yard") == true, "nightmare respawn")


	diff.set_difficulty("normal")
	# --- inventory ---
	var inv: Node = InventoryManager
	_check(inv.add_item("flashlight"), "inv add")
	_check(inv.add_item("battery"), "inv add2")
	_check(inv.has_item("flashlight"), "inv has")
	var res: String = inv.try_combine("flashlight", "battery")
	_check(res == "flashlight_charged", "inv combine")
	_check(not inv.has_item("battery"), "battery consumed")
	inv.reset()
	_check(inv.add_item("gear") and inv.add_item("gear"), "gear stack")
	_check(inv.count_item("gear") == 2, "gear count")
	inv.reset()

	# --- save manager ---
	var saves: Node = SaveManager
	saves.write_save({"difficulty": "hard", "run_time": 42.5})
	_check(saves.has_save(), "save write")
	var data: Dictionary = saves.read_save()
	_check(data.get("difficulty", "") == "hard", "save read")
	saves.delete_save()
	_check(not saves.has_save(), "save delete")


	# --- settings ---
	var st: Node = SettingsManager
	st.set_quality("ultra")
	_check(st.msaa_level == 2, "quality ultra")
	st.set_quality("low")
	_check(st.msaa_level == 0, "quality low")
	st.language = "en"
	st.apply_all()


	# --- game manager state ---
	var game: Node = Game
	game.difficulty = "normal"
	game.story_flags = {"entered_house": true}
	var pz: Array[String] = ["generator", "breaker"]
	game.puzzles_solved = pz
	game.items_collected_total = 7
	var payload: Dictionary = game.serialize_state()
	_check(payload.get("puzzles_solved", []).size() == 2, "serialize")
	var game2: Node = Game
	var saved_flags: Dictionary = game.story_flags
	var saved_puz: Array = game.puzzles_solved
	var saved_items: int = game.items_collected_total
	game.story_flags = {"entered_house": true}
	game.items_collected_total = 7
	game2.load_state(game.serialize_state())
	_check(game2.has_flag("entered_house"), "load flags")
	_check(game2.items_collected_total == 7, "load items")
	_check(game2.format_time(125.0) == "02:05", "time format")
	game.story_flags = saved_flags
	var pz2: Array[String] = []
	for p in saved_puz:
		pz2.append(p)
	game.puzzles_solved = pz2
	game.items_collected_total = saved_items

	# --- audio files ---
	for p in ["res://audio/music_menu.ogg", "res://audio/music_chase.ogg", "res://audio/ui_click.ogg",
			"res://audio/monster_growl_1.ogg", "res://audio/step_wood_1.ogg", "res://audio/generator_loop.ogg"]:
		if not ResourceLoader.exists(p):
			printerr("missing audio: ", p)
			fails += 1
	_check(true, "audio files")

	# --- models present ---
	for p in ["res://models/characters/milik_friendly.glb", "res://models/characters/milik_evil.glb",
			"res://models/characters/milik_toy.glb", "res://models/props/Sofa_01/Sofa_01_1k.gltf",
			"res://models/environment/Wall_Cell_Door.glb"]:
		if not ResourceLoader.exists(p):
			printerr("missing model: ", p)
			fails += 1
	_check(true, "models")

	# --- character scenes instantiate ---
	for sp in ["res://scenes/characters/EvilMilik.tscn", "res://scenes/characters/MilikFriend.tscn"]:
		var ps: PackedScene = load(sp)
		var inst := ps.instantiate()
		_check(inst.get_child_count() >= 2, "char scene " + sp)
		inst.free()

	print("SMOKE TEST DONE, fails=", fails)
	get_tree().quit(1 if fails > 0 else 0)


func _check(cond: bool, name: String) -> void:
	if cond:
		print("  OK  ", name)
	else:
		printerr("  FAIL  ", name)
		fails += 1
