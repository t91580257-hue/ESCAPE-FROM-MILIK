extends CharacterBody3D
## First-person player: move, sprint, crouch, flashlight, interact, hiding, footsteps.

signal interact_target_changed(prompt_text: String)

const WALK_SPEED := 2.7
const RUN_SPEED := 4.4
const CROUCH_SPEED := 1.5
const ACCEL := 9.0
const GRAVITY := 12.0
const BOB_FREQ := 2.2
const BOB_AMP := 0.055
const MOUSE_SENS := 0.0022
const TOUCH_SENS := 0.0035

var head: Node3D
var camera: Camera3D
var flashlight: SpotLight3D
var flashlight_rig: Node3D

var move_input := Vector2.ZERO
var look_delta := Vector2.ZERO
var is_running := false
var is_crouching := false
var hidden_in: Node = null
var can_move := true  # false during cutscenes
var controls_enabled := true

var _base_head_y := 0.0
var _bob_time := 0.0
var _step_accum := 0.0
var _noise_accum := 0.0
var _current_interactable: Node = null
var _battery_drain := 0.0
var _surface := "wood"
var footstep_enabled := true


func _ready() -> void:
	add_to_group("player")
	head = $Head
	camera = $Head/Camera3D
	flashlight_rig = $Head/Camera3D/FlashlightRig
	flashlight = $Head/Camera3D/FlashlightRig/SpotLight3D
	_base_head_y = head.position.y
	flashlight.visible = false
	_apply_settings()


func _apply_settings() -> void:
	camera.fov = 70.0


func _unhandled_input(event: InputEvent) -> void:
	if not controls_enabled:
		return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		look_delta += event.relative * MOUSE_SENS * SettingsManager.sensitivity
	if event.is_action_pressed("interact"):
		do_interact()
	elif event.is_action_pressed("flashlight"):
		toggle_flashlight()
	elif event.is_action_pressed("crouch"):
		toggle_crouch()
	elif event.is_action_pressed("pause"):
		var pm := get_tree().get_first_node_in_group("pause_menu")
		if pm != null and pm.has_method("open_pause"):
			pm.open_pause()


func _physics_process(delta: float) -> void:
	if not controls_enabled:
		move_input = Vector2.ZERO
		is_running = false
	_is_on_floor_gravity(delta)
	_read_touch_controls()
	_process_look()
	if can_move and not hidden_in:
		_process_move(delta)
	else:
		velocity.x = 0
		velocity.z = 0
	move_and_slide()
	_process_head_bob(delta)
	_process_steps_and_noise(delta)
	_process_interact_ray()
	_process_flashlight(delta)


func _is_on_floor_gravity(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	else:
		velocity.y = 0.0


func _read_touch_controls() -> void:
	var tc := get_tree().get_first_node_in_group("touch_controls")
	if tc == null:
		return
	move_input = tc.get_move_vector()
	look_delta += tc.consume_look_delta() * TOUCH_SENS * SettingsManager.sensitivity
	is_running = tc.is_run_pressed()


func _process_look() -> void:
	if look_delta == Vector2.ZERO:
		return
	rotation.y -= look_delta.x
	var pitch := head.rotation.x
	var invert := -1.0 if SettingsManager.invert_y else 1.0
	pitch -= look_delta.y * invert
	head.rotation.x = clampf(pitch, -1.35, 1.25)
	look_delta = Vector2.ZERO


func _process_move(delta: float) -> void:
	var input_dir := move_input
	if Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down").length() > 0.1 and move_input == Vector2.ZERO:
		input_dir = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	var sprint := (is_running or Input.is_action_pressed("run")) and not is_crouching
	var crouching := is_crouching or Input.is_action_pressed("crouch")
	var speed := RUN_SPEED if sprint else (CROUCH_SPEED if crouching else WALK_SPEED)
	var dir := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	if dir.length() > 0.1:
		velocity.x = lerpf(velocity.x, dir.x * speed, ACCEL * delta)
		velocity.z = lerpf(velocity.z, dir.z * speed, ACCEL * delta)
	else:
		velocity.x = lerpf(velocity.x, 0.0, ACCEL * delta)
		velocity.z = lerpf(velocity.z, 0.0, ACCEL * delta)


func _process_head_bob(delta: float) -> void:
	var speed2d := Vector2(velocity.x, velocity.z).length()
	if speed2d > 0.5 and is_on_floor():
		_bob_time += delta * speed2d * 1.7
		var target_y := _base_head_y + sin(_bob_time * BOB_FREQ) * BOB_AMP
		head.position.y = lerpf(head.position.y, target_y, 10.0 * delta)
		head.rotation.z = sin(_bob_time * BOB_FREQ * 0.5) * 0.012
	else:
		head.position.y = lerpf(head.position.y, _base_head_y, 8.0 * delta)
		head.rotation.z = lerpf(head.rotation.z, 0.0, 8.0 * delta)
	# crouch height
	var target_base := -0.35 if (is_crouching or Input.is_action_pressed("crouch")) else 0.0
	_base_head_y = lerpf(_base_head_y, target_base + 0.0, 6.0 * delta) if target_base != 0.0 else lerpf(_base_head_y, 0.0, 6.0 * delta)


func _process_steps_and_noise(delta: float) -> void:
	var speed2d := Vector2(velocity.x, velocity.z).length()
	if speed2d < 0.6 or not is_on_floor() or hidden_in != null:
		return
	_step_accum += speed2d * delta
	_noise_accum += delta
	var crouching := is_crouching or Input.is_action_pressed("crouch")
	var sprint := is_running or Input.is_action_pressed("run")
	var loudness := 1.0 if sprint else (0.35 if crouching else 0.6)
	var step_len := 1.5 if sprint else (2.0 if crouching else 1.75)
	if _step_accum >= step_len:
		_step_accum = 0.0
		if footstep_enabled:
			AudioManager.play_footstep(get_parent(), global_position, _surface, loudness * 0.9)
		EventBus.noise_emitted.emit(global_position, 0.35 if crouching else (1.0 if sprint else 0.6), "footstep")
	if _noise_accum > 0.25:
		_noise_accum = 0.0


func _process_interact_ray() -> void:
	if hidden_in != null:
		_set_interactable(null)
		return
	var space := get_world_3d().direct_space_state
	var from := camera.global_position
	var to := from - camera.global_transform.basis.z * 2.4
	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.exclude = [self]
	var hit := space.intersect_ray(query)
	if hit.is_empty():
		_set_interactable(null)
		return
	var collider: Node = hit.get("collider")
	var target: Node = null
	var node: Node = collider
	while node != null:
		if node.has_method("get_interact_prompt"):
			target = node
			break
		node = node.get_parent()
	_set_interactable(target)


func _set_interactable(target: Node) -> void:
	if _current_interactable == target:
		return
	_current_interactable = target
	if target != null:
		interact_target_changed.emit(target.get_interact_prompt())
	else:
		interact_target_changed.emit("")


func do_interact() -> void:
	if hidden_in != null:
		exit_hiding()
		return
	if _current_interactable != null and _current_interactable.has_method("interact"):
		_current_interactable.interact(self)


func toggle_flashlight() -> void:
	if not Game.flashlight_unlocked:
		return
	flashlight.visible = not flashlight.visible
	AudioManager.play_sfx("flashlight_click", -8.0)
	EventBus.flashlight_toggled.emit(flashlight.visible)


func toggle_crouch() -> void:
	is_crouching = not is_crouching


func _process_flashlight(delta: float) -> void:
	if not Game.flashlight_unlocked:
		flashlight.visible = false
		return
	if flashlight.visible:
		Game.flashlight_battery = maxf(0.0, Game.flashlight_battery - delta * 0.012)
		var flicker := 1.0
		if Game.flashlight_battery < 0.2:
			flicker = randf_range(0.55, 1.0)
		flashlight.light_energy = 1.6 * flicker * (0.4 + 0.6 * Game.flashlight_battery)
		if Game.flashlight_battery <= 0.0:
			flashlight.visible = false
			AudioManager.play_sfx("flashlight_click", -8.0)


func unlock_flashlight() -> void:
	Game.flashlight_unlocked = true
	flashlight.visible = true
	AudioManager.play_sfx("pickup")


# ---------- hiding ----------
func enter_hiding(spot: Node) -> void:
	if hidden_in != null:
		return
	hidden_in = spot
	AudioManager.play_sfx("hide_in", -6.0)
	EventBus.player_hidden_changed.emit(true)


func exit_hiding() -> void:
	if hidden_in == null:
		return
	var spot := hidden_in
	hidden_in = null
	AudioManager.play_sfx("hide_out", -6.0)
	if spot.has_method("on_player_exit"):
		spot.on_player_exit(self)
	EventBus.player_hidden_changed.emit(false)


func is_hidden() -> bool:
	return hidden_in != null


func teleport_to(pos: Vector3) -> void:
	global_position = pos
	velocity = Vector3.ZERO


# ---------- caught ----------
func caught() -> void:
	if not can_move:
		return
	can_move = false
	controls_enabled = false


func set_surface(s: String) -> void:
	_surface = s
