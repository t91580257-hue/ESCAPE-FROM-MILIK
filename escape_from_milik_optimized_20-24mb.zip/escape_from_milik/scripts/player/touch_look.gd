extends Control
## Look area (right side): emits drag deltas consumed by the player.

var _touch_index := -1
var _last_pos := Vector2.ZERO
var pending_delta := Vector2.ZERO


func _ready() -> void:
	add_to_group("touch_look")
	mouse_filter = Control.MOUSE_FILTER_STOP
	set_anchors_preset(Control.PRESET_FULL_RECT)


func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and _touch_index == -1:
			_touch_index = event.index
			_last_pos = event.position
		elif not event.pressed and event.index == _touch_index:
			_touch_index = -1
	elif event is InputEventScreenDrag and event.index == _touch_index:
		pending_delta += event.position - _last_pos
		_last_pos = event.position


func consume_delta() -> Vector2:
	var d := pending_delta
	pending_delta = Vector2.ZERO
	return d
