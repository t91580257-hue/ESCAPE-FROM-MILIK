extends Control
## Virtual joystick (left side). Multi-touch aware.

var output := Vector2.ZERO
var radius := 110.0
var _touch_index := -1
var _center := Vector2.ZERO
var _bg_color := Color(1, 1, 1, 0.10)
var _knob_color := Color(1, 1, 1, 0.28)


func _ready() -> void:
	add_to_group("touch_joystick")
	mouse_filter = Control.MOUSE_FILTER_STOP
	custom_minimum_size = Vector2(320, 320)
	size = Vector2(320, 320)


func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and _touch_index == -1:
			_touch_index = event.index
			_center = event.position
			accept_event()
		elif not event.pressed and event.index == _touch_index:
			_touch_index = -1
			output = Vector2.ZERO
			queue_redraw()
			accept_event()
	elif event is InputEventScreenDrag and event.index == _touch_index:
		var rel: Vector2 = event.position - _center
		rel = rel.limit_length(radius)
		output = rel / radius
		queue_redraw()
		accept_event()


func get_move_vector() -> Vector2:
	return output


func set_visual_scale(s: float) -> void:
	radius = 110.0 * s
	queue_redraw()


func set_opacity(a: float) -> void:
	_bg_color.a = 0.10 * a
	_knob_color.a = 0.30 * a
	queue_redraw()


func _draw() -> void:
	var c := _center if _touch_index != -1 else size * 0.5
	draw_circle(c, radius, _bg_color)
	draw_arc(c, radius, 0, TAU, 48, Color(1, 1, 1, 0.16), 2.0)
	var knob_pos := c + output * radius
	draw_circle(knob_pos, radius * 0.42, _knob_color)
	draw_circle(knob_pos, radius * 0.42, Color(1, 1, 1, 0.1))
