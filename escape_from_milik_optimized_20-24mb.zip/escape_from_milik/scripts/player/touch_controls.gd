extends Control
## TouchControls: HUD overlay with joystick, look area and action buttons.

signal pause_requested

var joystick: Control
var look_area: Control
var _buttons: Dictionary = {}

const BTN_STYLE := "flat"


func _ready() -> void:
	add_to_group("touch_controls")
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_build_controls()
	apply_settings()


func _build_controls() -> void:
	# look area behind buttons (full rect)
	look_area = Control.new()
	look_area.set_script(load("res://scripts/player/touch_look.gd"))
	look_area.set_anchors_preset(Control.PRESET_FULL_RECT)
	look_area.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(look_area)

	# joystick bottom-left
	joystick = Control.new()
	joystick.set_script(load("res://scripts/player/touch_joystick.gd"))
	joystick.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	joystick.position = Vector2(30, -350)
	joystick.size = Vector2(320, 320)
	joystick.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(joystick)

	# right-side action buttons
	_add_action_button("interact", Localization.tr_key("hud.interact"), Vector2(-250, -250), Color(1.0, 0.85, 0.4))
	_add_action_button("run", Localization.tr_key("hud.run"), Vector2(-100, -250), Color(0.6, 1.0, 0.6))
	_add_action_button("crouch", Localization.tr_key("hud.crouch"), Vector2(-100, -120), Color(0.55, 0.7, 1.0))
	_add_action_button("hide", Localization.tr_key("hud.hide"), Vector2(-250, -120), Color(0.8, 0.6, 1.0))
	_add_action_button("flashlight", "F", Vector2(-250, -390), Color(1.0, 1.0, 0.55))
	_add_action_button("inventory", Localization.tr_key("hud.inventory"), Vector2(-100, -390), Color(1.0, 0.6, 0.6))
	_add_action_button("pause", "II", Vector2(-30, 30), Color(1, 1, 1))


func _add_action_button(action: String, text: String, offset: Vector2, color: Color) -> void:
	var b := Button.new()
	b.text = text
	b.name = action.capitalize()
	b.add_to_group("touch_buttons")
	b.custom_minimum_size = Vector2(130, 110) if action != "pause" else Vector2(70, 70)
	b.size = b.custom_minimum_size
	b.mouse_filter = Control.MOUSE_FILTER_STOP
	b.add_theme_font_size_override("font_size", 26 if action != "pause" else 30)
	b.add_theme_color_override("font_color", color)
	b.add_theme_color_override("font_pressed_color", color.lightened(0.3))
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.05, 0.05, 0.08, 0.55)
	sb.set_corner_radius_all(18)
	sb.border_color = Color(color.r, color.g, color.b, 0.5)
	sb.set_border_width_all(2)
	b.add_theme_stylebox_override("normal", sb)
	var sbp := sb.duplicate()
	sbp.bg_color = Color(color.r, color.g, color.b, 0.25)
	b.add_theme_stylebox_override("pressed", sbp)
	b.add_theme_stylebox_override("hover", sb)
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT if offset.x < 0 else Control.PRESET_TOP_RIGHT)
	b.position = Vector2(0, 0)
	b.offset_right = offset.x
	b.offset_bottom = offset.y
	b.offset_top = offset.y - b.custom_minimum_size.y
	b.offset_left = offset.x - b.custom_minimum_size.x
	add_child(b)
	_buttons[action] = b
	b.pressed.connect(_on_button_pressed.bind(action))
	b.button_down.connect(_on_button_down.bind(action))
	b.button_up.connect(_on_button_up.bind(action))


func _on_button_pressed(action: String) -> void:
	AudioManager.ui_click()
	match action:
		"pause":
			pause_requested.emit()
		"inventory":
			var inv := get_tree().get_first_node_in_group("inventory_ui")
			if inv != null and inv.has_method("toggle"):
				inv.toggle()
		_:
			pass


func _on_button_down(action: String) -> void:
	match action:
		"interact":
			Input.action_press("interact")
		"run":
			Input.action_press("run")
		"crouch":
			Input.action_press("crouch")
		"hide":
			Input.action_press("hide")
		"flashlight":
			Input.action_press("flashlight")


func _on_button_up(action: String) -> void:
	match action:
		"interact", "run", "crouch", "hide", "flashlight":
			Input.action_release(action)


func get_move_vector() -> Vector2:
	return joystick.get_move_vector() if joystick.has_method("get_move_vector") else Vector2.ZERO


func consume_look_delta() -> Vector2:
	return look_area.consume_delta() if look_area.has_method("consume_delta") else Vector2.ZERO


func is_run_pressed() -> bool:
	var b: Button = _buttons.get("run")
	return b != null and b.is_pressed()


func apply_settings() -> void:
	joystick.set_visual_scale(SettingsManager.joystick_size)
	joystick.set_opacity(SettingsManager.button_opacity)
	for action in _buttons:
		var b: Button = _buttons[action]
		b.modulate.a = clampf(SettingsManager.button_opacity + 0.25, 0.0, 1.0)


func set_visible_controls(v: bool) -> void:
	visible = v


func refresh_texts() -> void:
	_buttons["interact"].text = Localization.tr_key("hud.interact")
	_buttons["run"].text = Localization.tr_key("hud.run")
	_buttons["crouch"].text = Localization.tr_key("hud.crouch")
	_buttons["hide"].text = Localization.tr_key("hud.hide")
	_buttons["inventory"].text = Localization.tr_key("hud.inventory")
