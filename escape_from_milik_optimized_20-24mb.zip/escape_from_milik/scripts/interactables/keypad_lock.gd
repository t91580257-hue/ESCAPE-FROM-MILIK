extends StaticBody3D
## Keypad-locked door (pantry). Opens keypad UI on interact.

@export var lock_id: String = "pantry"
@export var correct_code: String = "472"
@export var door_path: NodePath  # door node to unlock

var _door: Node = null


func _ready() -> void:
	add_to_group("keypad_locks")
	if door_path != null:
		_door = get_node_or_null(door_path)
	EventBus.open_keypad.connect(_on_keypad_result_check)


func get_interact_prompt() -> String:
	return Localization.tr_key("world.keypad_hint")


func interact(_player: Node) -> void:
	EventBus.open_keypad.emit(lock_id)
	# UI connects to keypad_entered
	if not EventBus.keypad_entered.is_connected(_on_keypad_entered):
		EventBus.keypad_entered.connect(_on_keypad_entered)


func _on_keypad_result_check(_lid: String) -> void:
	pass


func _on_keypad_entered(_lid: String, code: String) -> void:
	if _lid != lock_id:
		return
	if code == correct_code:
		AudioManager.play_sfx("puzzle_success")
		UIManager.show_message(Localization.tr_key("hud.open"), 2.0)
		if _door != null and _door.has_method("_try_unlock"):
			_door.locked = false
			_door._try_unlock()
		elif _door != null and _door.has_method("_toggle"):
			_door.locked = false
			_door._toggle()
		if not Game.puzzles_solved.has("pantry_code"):
			EventBus.puzzle_solved.emit("pantry_code")
		EventBus.keypad_entered.disconnect(_on_keypad_entered)
	else:
		AudioManager.play_sfx("puzzle_error", -4.0)
		SettingsManager.vibrate(70)
		UIManager.show_message(Localization.tr_key("hud.locked"), 1.5)
