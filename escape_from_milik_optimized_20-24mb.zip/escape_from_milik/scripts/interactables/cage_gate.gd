extends StaticBody3D
## Cage gate: install 3 gears, then crank 3 times. Opens the cage; triggers rescue.

@export var gate_id: String = "cage_gate"
@export var gears_needed: int = 3

var gears_installed := 0
var cranks_done := 0
var opening := false
var opened := false

@onready var gate_pivot: Node3D = $GatePivot
@onready var crank_wheel: Node3D = $CrankWheel


func get_interact_prompt() -> String:
	if opened:
		return ""
	if opening:
		return Localization.tr_key("world.cage_crank")
	return Localization.tr_key("world.cage_gate")


func interact(_player: Node) -> void:
	if opened or opening:
		return
	if not EventBus.breaker_solved.is_connected(_noop):
		pass
	if not Game.has_flag("breaker_ok"):
		UIManager.show_message(Localization.tr_key("world.cage_no_power"), 2.5)
		AudioManager.play_sfx("puzzle_error", -6.0)
		return
	if gears_installed < gears_needed:
		var have := InventoryManager.count_item("gear")
		if have <= 0:
			UIManager.show_message(Localization.tr_key("world.cage_need_gears") % [gears_installed, gears_needed], 2.5)
			AudioManager.play_sfx("puzzle_error", -6.0)
			return
		var take: int = mini(have, gears_needed - gears_installed)
		InventoryManager.remove_item("gear", take)
		gears_installed += take
		AudioManager.play_sfx("puzzle_click", -2.0)
		UIManager.show_message(Localization.tr_key("world.cage_gear_installed") % [gears_installed, gears_needed], 2.0)
		_spin_crank_wheel()
		if gears_installed >= gears_needed:
			opening = true
			UIManager.show_message(Localization.tr_key("world.cage_crank"), 2.0)
		return
	if opening:
		_crank(_player)


func _noop() -> void:
	pass


func _spin_crank_wheel() -> void:
	if crank_wheel != null:
		var tw := create_tween()
		tw.tween_property(crank_wheel, "rotation_degrees:z", crank_wheel.rotation_degrees.z + 120.0, 0.6).set_trans(Tween.TRANS_CUBIC)


func _crank(_player: Node) -> void:
	cranks_done += 1
	AudioManager.play_sfx_3d("cage_open", get_parent(), global_position, "SFX", -4.0)
	SettingsManager.vibrate(90)
	_spin_crank_wheel()
	var latch := get_node_or_null("Latch") as Node3D
	if latch != null:
		var tw := create_tween()
		tw.tween_property(latch, "position:y", latch.position.y - 0.08 * cranks_done, 0.3)
	if cranks_done >= 3:
		_open_gate()


func _open_gate() -> void:
	opening = false
	opened = true
	EventBus.puzzle_solved.emit("cage_gate")
	AudioManager.play_sfx_3d("cage_open", get_parent(), global_position, "SFX", 0.0)
	var tw := create_tween()
	tw.tween_property(gate_pivot, "rotation_degrees:y", -110.0, 2.2).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_callback(func():
		var level := get_tree().get_first_node_in_group("level")
		if level != null and level.has_method("on_cage_opened"):
			level.on_cage_opened())


func serialize_state() -> Dictionary:
	return {"gears": gears_installed, "cranks": cranks_done, "opened": opened}


func restore_state(d: Dictionary) -> void:
	gears_installed = int(d.get("gears", 0))
	cranks_done = int(d.get("cranks", 0))
	if d.get("opened", false):
		opened = true
		gate_pivot.rotation_degrees.y = -110.0
	elif gears_installed >= gears_needed:
		opening = true
