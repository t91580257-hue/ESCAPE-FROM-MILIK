extends StaticBody3D
## Breaker panel: flip 3 levers in the order from the note (2-1-3).

@export var panel_id: String = "basement_breaker"
@export var correct_order: Array = [2, 1, 3]

var solved := false
var _entered: Array = []

@onready var lever1: Node3D = $Lever1
@onready var lever2: Node3D = $Lever2
@onready var lever3: Node3D = $Lever3


func get_interact_prompt() -> String:
	if solved:
		return Localization.tr_key("world.breaker") + " — OK"
	return Localization.tr_key("world.breaker")


func interact(_player: Node) -> void:
	if solved:
		return
	if not Game.power_on:
		UIManager.show_message(Localization.tr_key("world.generator_need_power"), 2.5)
		return
	# one interact = flip the next lever in sequence UI-less (touch friendly):
	# first interact opens selection; use simple 3-press cycle:
	_open_selector()


func _open_selector() -> void:
	# The selector UI is spawned by HUD (breaker_ui). Simple approach:
	EventBus.open_breaker.emit(panel_id)
	if not EventBus.breaker_flipped.is_connected(_on_flip):
		EventBus.breaker_flipped.connect(_on_flip)


func _on_flip(pid: String, lever_index: int) -> void:
	if pid != panel_id or solved:
		return
	var lever: Node3D = [lever1, lever2, lever3][lever_index - 1]
	var tw := create_tween()
	tw.tween_property(lever, "rotation_degrees:x", -60.0, 0.25).set_trans(Tween.TRANS_BACK)
	AudioManager.play_sfx("switch_flip", -2.0)
	_entered.append(lever_index)
	if _entered.size() >= correct_order.size():
		var ok := true
		for i in correct_order.size():
			if _entered[i] != correct_order[i]:
				ok = false
				break
		if ok:
			solved = true
			AudioManager.play_sfx("puzzle_success")
			UIManager.show_message(Localization.tr_key("puzzle.breaker_solved"), 3.0)
			EventBus.puzzle_solved.emit("breaker")
			EventBus.breaker_solved.emit(panel_id)
			EventBus.breaker_flipped.disconnect(_on_flip)
		else:
			_reset_levers()
			AudioManager.play_sfx("puzzle_error", -4.0)
			UIManager.show_message(Localization.tr_key("puzzle.breaker_wrong"), 2.0)
			_entered.clear()


func _reset_levers() -> void:
	for lever in [lever1, lever2, lever3]:
		var tw := create_tween()
		tw.tween_property(lever, "rotation_degrees:x", 0.0, 0.3)


func serialize_state() -> Dictionary:
	return {"solved": solved}


func restore_state(d: Dictionary) -> void:
	if d.get("solved", false):
		solved = true
		for lever in [lever1, lever2, lever3]:
			lever.rotation_degrees.x = -60.0
		EventBus.breaker_solved.emit(panel_id)
