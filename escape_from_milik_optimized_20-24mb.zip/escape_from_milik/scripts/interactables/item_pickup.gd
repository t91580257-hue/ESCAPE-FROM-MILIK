extends StaticBody3D
## Item pickup: adds an item to the inventory on interact, then disappears.

@export var item_id: String = "gear"
@export var pickup_sound: String = "pickup"
@export var auto_interact: bool = false  # for flashlight on the table etc.

var _collected := false


func _ready() -> void:
	add_to_group("pickups")
	if item_id == "flashlight":
		add_to_group("flashlight_pickup")


func get_interact_prompt() -> String:
	if _collected:
		return ""
	var name_txt := InventoryManager.get_item_name(item_id)
	return Localization.tr_key("hud.pickup") + " — " + name_txt


func interact(_player: Node) -> void:
	if _collected:
		return
	if InventoryManager.add_item(item_id):
		_collected = true
		AudioManager.play_sfx(pickup_sound, -4.0)
		var name_txt := InventoryManager.get_item_name(item_id)
		UIManager.show_message("+ " + name_txt, 2.0)
		SettingsManager.vibrate(40, 0.4)
		if item_id == "flashlight":
			Game.flashlight_unlocked = true
		EventBus.item_picked.emit(item_id)
		# small scale-out animation then free
		var mesh := find_child("Model", true, false) as Node3D
		if mesh == null:
			queue_free()
		else:
			var tw := create_tween()
			tw.tween_property(mesh, "scale", Vector3.ONE * 0.01, 0.25).set_trans(Tween.TRANS_QUAD)
			tw.tween_callback(queue_free)
