extends StaticBody3D
## Hiding spot (wardrobe). Player enters, monster may check it.

@export var interior_offset: Vector3 = Vector3(0, 0, 0.1)

var occupied_by: Node = null

@onready var door_left: Node3D = get_node_or_null("DoorLeft")
@onready var door_right: Node3D = get_node_or_null("DoorRight")


func _ready() -> void:
	add_to_group("hide_spots")


func get_interact_prompt() -> String:
	if occupied_by != null:
		return Localization.tr_key("hud.leave")
	return Localization.tr_key("hud.hide")


func interact(player: Node) -> void:
	if occupied_by != null:
		return
	AudioManager.play_sfx("hide_in", -4.0)
	_open_doors(true)
	if player.has_method("enter_hiding"):
		var prev_pos: Vector3 = player.global_position
		var inside: Vector3 = global_position + global_transform.basis * interior_offset
		player.set_meta("hide_return_pos", prev_pos)
		player.enter_hiding(self)
		player.teleport_to(inside)
		# face outward
		var out_dir := -global_transform.basis.z
		var yaw := atan2(-out_dir.x, -out_dir.z)
		if player is CharacterBody3D:
			player.rotation.y = yaw
	occupied_by = player


func on_player_exit(player: Node) -> void:
	occupied_by = null
	AudioManager.play_sfx("hide_out", -4.0)
	_open_doors(false)
	if player.has_meta("hide_return_pos"):
		var pos: Vector3 = player.get_meta("hide_return_pos")
		if player.has_method("teleport_to"):
			player.teleport_to(pos)


func _open_doors(open: bool) -> void:
	var angle := 95.0 if open else 0.0
	if door_left != null:
		var tw := create_tween()
		tw.tween_property(door_left, "rotation_degrees:y", angle, 0.35).set_trans(Tween.TRANS_SINE)
	if door_right != null:
		var tw2 := create_tween()
		tw2.tween_property(door_right, "rotation_degrees:y", -angle, 0.35).set_trans(Tween.TRANS_SINE)
