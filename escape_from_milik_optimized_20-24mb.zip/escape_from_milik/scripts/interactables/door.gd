extends StaticBody3D
## Interactive hinged door. Emits noise events; locked variants need keys.

@export var door_id: String = "door"
@export var locked: bool = false
@export var lock_type: String = ""  # "", "key_nursery", "key_basement"
@export var open_angle_deg: float = 100.0
@export var open_speed: float = 1.4
@export var start_open: bool = false

var is_open := false
var _anim_lock := false

@onready var pivot: Node3D = $Pivot


func _ready() -> void:
	add_to_group("doors")
	is_open = start_open
	if is_open:
		pivot.rotation_degrees.y = open_angle_deg


func get_interact_prompt() -> String:
	if locked:
		return Localization.tr_key("hud.locked")
	return Localization.tr_key("hud.open") if not is_open else Localization.tr_key("hud.close")


func interact(_player: Node) -> void:
	if _anim_lock:
		return
	if locked:
		_try_unlock()
		return
	_toggle()


func _try_unlock() -> void:
	if lock_type == "":
		locked = false
		_toggle()
		return
	if InventoryManager.has_item(lock_type):
		InventoryManager.remove_item(lock_type, 1)
		locked = false
		AudioManager.play_sfx("puzzle_success", -6.0)
		UIManager.show_message(Localization.tr_key("hud.open"), 1.5)
		_toggle()
	else:
		AudioManager.play_sfx("door_locked", -4.0)
		SettingsManager.vibrate(50)
		var msg_key := "world.locked_nursery" if lock_type == "key_nursery" else "world.locked_basement"
		UIManager.show_message(Localization.tr_key(msg_key), 2.5)


func _toggle() -> void:
	_anim_lock = true
	is_open = not is_open
	var target := open_angle_deg if is_open else 0.0
	var tw := create_tween()
	tw.tween_property(pivot, "rotation_degrees:y", target, open_speed).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tw.tween_callback(func(): _anim_lock = false)
	var snd := "door_open" if is_open else "door_close"
	AudioManager.play_sfx_3d(snd, get_parent(), pivot.global_position, "SFX", -2.0)
	EventBus.noise_emitted.emit(pivot.global_position, 0.5, "door")
	EventBus.door_toggled.emit(door_id, is_open)
	# door state is saved via level (it scans door states)
