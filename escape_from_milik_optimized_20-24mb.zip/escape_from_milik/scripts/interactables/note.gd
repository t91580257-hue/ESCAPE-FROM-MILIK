extends StaticBody3D
## Readable note: opens the note reader UI.

@export var note_id: String = "1"


func _ready() -> void:
	add_to_group("notes")


func get_interact_prompt() -> String:
	return Localization.tr_key("hud.read") + " — " + Localization.tr_key("note." + note_id + ".title")


func interact(_player: Node) -> void:
	AudioManager.play_sfx("paper", -6.0)
	EventBus.show_note.emit(note_id)
