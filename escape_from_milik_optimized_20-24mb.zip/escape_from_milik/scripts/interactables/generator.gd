extends StaticBody3D
## Basement generator: needs fuse module + fuel canister, then cranks to life.

@export var generator_id: String = "basement_generator"

var running := false

@onready var hum_player: AudioStreamPlayer3D = $HumPlayer


func _ready() -> void:
	add_to_group("generator")
	if hum_player != null:
		hum_player.stop()


func get_interact_prompt() -> String:
	if running:
		return Localization.tr_key("world.generator") + " — OK"
	return Localization.tr_key("world.generator")


func interact(_player: Node) -> void:
	if running:
		return
	if not InventoryManager.has_item("fuel"):
		UIManager.show_message(Localization.tr_key("world.generator_need_fuel"), 2.5)
		AudioManager.play_sfx("puzzle_error", -6.0)
		return
	if not InventoryManager.has_item("fuse"):
		UIManager.show_message(Localization.tr_key("world.generator_need_fuse"), 2.5)
		AudioManager.play_sfx("puzzle_error", -6.0)
		return
	InventoryManager.remove_item("fuel", 1)
	InventoryManager.remove_item("fuse", 1)
	_start()


func _start() -> void:
	running = true
	AudioManager.play_sfx_3d("generator_start", get_parent(), global_position, "SFX", 2.0)
	SettingsManager.vibrate(120, 0.8)
	# crank shake
	var tw := create_tween()
	tw.tween_property(self, "rotation_degrees:z", 1.2, 0.08)
	tw.tween_property(self, "rotation_degrees:z", -1.2, 0.08)
	tw.tween_property(self, "rotation_degrees:z", 0.6, 0.08)
	tw.tween_property(self, "rotation_degrees:z", 0.0, 0.08)
	tw.tween_callback(func():
		if hum_player != null:
			hum_player.play()
		Game.set_power(true)
		UIManager.show_message(Localization.tr_key("world.power_on"), 3.5)
		EventBus.puzzle_solved.emit("generator")
		Game.raise_aggression(2)
	)
