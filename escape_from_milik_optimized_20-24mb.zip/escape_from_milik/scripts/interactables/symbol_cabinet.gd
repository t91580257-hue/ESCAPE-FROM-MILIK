extends StaticBody3D
## Symbol cabinet in the living room: press 4 symbols in room order.
## Correct sequence: ENTRY(0), LIVING(1), KITCHEN(2), CORRIDOR(3) -> indexes of the symbols.

@export var cabinet_id: String = "living_cabinet"
@export var correct_sequence: Array = [2, 0, 3, 1]  # symbol indexes in press order
@export var reward_item: String = "key_nursery"

var solved := false

@onready var reward_pickup: Node3D = $RewardPickup


func _ready() -> void:
	add_to_group("symbol_cabinets")
	if reward_pickup != null:
		reward_pickup.visible = false
		reward_pickup.process_mode = Node.PROCESS_MODE_DISABLED
	EventBus.symbols_entered.connect(_on_symbols)


func get_interact_prompt() -> String:
	if solved:
		return ""
	return Localization.tr_key("world.symbol_cabinet")


func interact(_player: Node) -> void:
	if solved:
		return
	EventBus.open_symbols.emit(cabinet_id)
	if not EventBus.symbols_entered.is_connected(_on_symbols):
		EventBus.symbols_entered.connect(_on_symbols)


func _on_symbols(cid: String, sequence: Array) -> void:
	if cid != cabinet_id or solved:
		return
	if sequence == correct_sequence:
		solved = true
		AudioManager.play_sfx("puzzle_success")
		UIManager.show_message(Localization.tr_key("puzzle.cabinet_solved"), 3.0)
		EventBus.puzzle_solved.emit("symbol_cabinet")
		_open_doors()
		if reward_pickup != null:
			reward_pickup.visible = true
			reward_pickup.process_mode = Node.PROCESS_MODE_INHERIT
			var tw := create_tween()
			tw.tween_property(reward_pickup, "scale", Vector3.ONE, 0.5).from(Vector3.ONE * 0.05).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	else:
		AudioManager.play_sfx("puzzle_error", -4.0)
		UIManager.show_message(Localization.tr_key("hud.locked"), 1.2)


func _open_doors() -> void:
	var left := get_node_or_null("DoorLeft") as Node3D
	var right := get_node_or_null("DoorRight") as Node3D
	if left != null:
		var tw := create_tween()
		tw.tween_property(left, "rotation_degrees:y", -95.0, 1.2).set_trans(Tween.TRANS_SINE)
	if right != null:
		var tw2 := create_tween()
		tw2.tween_property(right, "rotation_degrees:y", 95.0, 1.2).set_trans(Tween.TRANS_SINE)
	AudioManager.play_sfx_3d("door_open", get_parent(), global_position, "SFX", -6.0)


func serialize_state() -> Dictionary:
	return {"solved": solved}


func restore_state(d: Dictionary) -> void:
	if d.get("solved", false):
		solved = true
		_open_doors()
		if reward_pickup != null and not reward_pickup.visible:
			if InventoryManager.has_item(reward_item):
				reward_pickup.visible = false
			else:
				reward_pickup.visible = true
				reward_pickup.process_mode = Node.PROCESS_MODE_INHERIT
