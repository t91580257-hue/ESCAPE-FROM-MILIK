extends Node3D
## Flickering light. Attach to OmniLight3D/SpotLight3D parent node.

@export var flicker_enabled: bool = false
@export var min_energy := 0.15
@export var max_energy := 1.0
@export var speed := 9.0

var _t := 0.0
var _target := 1.0
var light: Light3D = null


func _ready() -> void:
	add_to_group("flicker_lights")
	light = get_child(0) as Light3D if get_child_count() > 0 else null
	if light == null and get_parent() is Light3D:
		light = get_parent()
	if light == null:
		set_physics_process(false)
		return
	if flicker_enabled:
		light.set_meta("target_energy", light.light_energy)


func set_enabled(v: bool) -> void:
	flicker_enabled = v


func _physics_process(delta: float) -> void:
	if not flicker_enabled or light == null:
		return
	_t += delta * speed
	if _t >= 1.0:
		_t = 0.0
		_target = randf_range(min_energy, max_energy) if randf() < 0.5 else max_energy
	light.light_energy = lerpf(light.light_energy, _target * float(light.get_meta("target_energy", 1.0)), 0.4)
