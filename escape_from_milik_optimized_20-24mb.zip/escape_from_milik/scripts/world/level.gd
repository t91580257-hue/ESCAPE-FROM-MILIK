extends Node3D
## Level orchestrator: waypoint graph, story triggers, cutscenes, catch/respawn, saves.

@export var player_path: NodePath
@export var monster_path: NodePath
@export var friend_path: NodePath
@export var waypoints_path: NodePath
@export var patrol_points_path: NodePath

var player: CharacterBody3D
var monster: CharacterBody3D
var friend: Node3D
var astar := AStar3D.new()
var _wp_ids: Dictionary = {}  # node -> astar id
var _door_edges: Dictionary = {}  # door_id -> [id_a, id_b]
var _monster_home := Vector3.ZERO
var _cameo_running := false
var _catch_ui_open := false
var _saved_zone_music := "ambient"
var _pending_restore: Dictionary = {}
var _victory_open := false


func _ready() -> void:
        add_to_group("level")
        player = get_node_or_null(player_path) as CharacterBody3D
        monster = get_node_or_null(monster_path) as CharacterBody3D
        friend = get_node_or_null(friend_path) as Node3D
        _monster_home = monster.global_position if monster != null else Vector3.ZERO
        if monster != null:
                monster.set_level(self)
        if friend != null and player != null:
                friend.set_target(player)
        _build_nav_graph()
        _connect_signals()
        _setup_ambience()
        _apply_music_zone("yard")
        UIManager.register_hud(get_tree().get_first_node_in_group("hud"))
        # restore or start
        if Game.pending_load:
                _pending_restore = Game.pending_load_payload
                Game.pending_load = false
                call_deferred("_restore_world")
        else:
                call_deferred("_start_intro")
        # pause handling
        var pm := get_tree().get_first_node_in_group("pause_menu")
        if pm != null and pm.has_method("bind_level"):
                pm.bind_level(self)


func _build_nav_graph() -> void:
        var wp_root := get_node_or_null(waypoints_path)
        if wp_root == null:
                return
        var id := 0
        var nodes: Array[Node3D] = []
        for c in wp_root.get_children():
                if c is Node3D:
                        nodes.append(c)
                        astar.add_point(id, c.global_position)
                        _wp_ids[c] = id
                        id += 1
        # proximity + LOS edges
        for i in nodes.size():
                for j in range(i + 1, nodes.size()):
                        var a := nodes[i]
                        var b := nodes[j]
                        var d := a.global_position.distance_to(b.global_position)
                        if d > 3.6:
                                continue
                        if _los_clear(a.global_position, b.global_position):
                                astar.connect_points(_wp_ids[a], _wp_ids[b], false)
        # explicit links (stairs, ramps, long hops)
        for c in wp_root.get_children():
                if c is Node3D and c.has_meta("links"):
                        var links: String = str(c.get_meta("links"))
                        for lk in links.split("|"):
                                var other := wp_root.get_node_or_null(NodePath(lk.strip_edges())) as Node3D
                                if other != null and _wp_ids.has(c) and _wp_ids.has(other):
                                        astar.connect_points(_wp_ids[c], _wp_ids[other], false)
        # door dynamic edges: door nodes carry WP_A / WP_B children
        for door in get_tree().get_nodes_in_group("doors"):
                var wpa := door.get_node_or_null("WP_A") as Node3D
                var wpb := door.get_node_or_null("WP_B") as Node3D
                if wpa == null or wpb == null:
                        continue
                # ensure side waypoints exist in graph
                for w in [wpa, wpb]:
                        if not _wp_ids.has(w):
                                astar.add_point(id, w.global_position)
                                _wp_ids[w] = id
                                id += 1
                        for n in nodes:
                                if n == w:
                                        continue
                                if _los_clear(w.global_position, n.global_position, 2.6):
                                        astar.connect_points(_wp_ids[w], _wp_ids[n], false)
                var ida: int = _wp_ids[wpa]
                var idb: int = _wp_ids[wpb]
                _door_edges[door.door_id] = [ida, idb]
        if monster != null and monster.has_method("setup_navigation"):
                var pts: Array[Vector3] = []
                for k in astar.get_point_ids():
                        pts.append(astar.get_point_position(k))
                monster.setup_navigation(astar, pts)


func _los_clear(a: Vector3, b: Vector3, max_dist: float = 4.0) -> bool:
        if a.distance_to(b) > max_dist + 0.001:
                return false
        var space := get_world_3d().direct_space_state
        var query := PhysicsRayQueryParameters3D.create(a + Vector3.UP * 0.35, b + Vector3.UP * 0.35)
        query.collide_with_areas = false
        var hit := space.intersect_ray(query)
        return hit.is_empty()


func _connect_signals() -> void:
        EventBus.door_toggled.connect(_on_door_toggled)
        EventBus.puzzle_solved.connect(_on_puzzle_solved)
        EventBus.monster_state_changed.connect(_on_monster_state)
        EventBus.story_flag_set.connect(_on_story_flag)
        EventBus.show_note.connect(_on_note_shown)


func _setup_ambience() -> void:
        # ambient emitters are placed in the scene; music zones set by triggers
        pass


func _apply_music_zone(zone: String) -> void:
        if _saved_zone_music == zone:
                return
        _saved_zone_music = zone
        AudioManager.play_music(zone, 2.0, -10.0)


# ---------- door graph ----------
func _on_door_toggled(door_id: String, opened: bool) -> void:
        if _door_edges.has(door_id):
                var pair: Array = _door_edges[door_id]
                if opened:
                        astar.connect_points(pair[0], pair[1], false)
                else:
                        if astar.are_points_connected(pair[0], pair[1]):
                                astar.disconnect_points(pair[0], pair[1])


# ---------- puzzles ----------
func _on_puzzle_solved(id: String) -> void:
        match id:
                "symbol_cabinet":
                        _set_objective_key("objective.find_nursery_key_used")
                        Game.set_flag("cabinet_solved")
                        Game.raise_aggression(1)
                        _apply_music_zone("ambient")
                "pantry_code":
                        Game.set_flag("pantry_open")
                "generator":
                        Game.set_flag("power_on_done")
                        _apply_music_zone("ambient")
                        _on_power_on()
                "breaker":
                        Game.set_flag("breaker_ok")
                        _set_objective_key("objective.fix_cage")
                "cage_gate":
                        pass
        autosave_world()


func _on_power_on() -> void:
        # switch on house lights
        var lights := get_tree().get_nodes_in_group("power_lights")
        for l in lights:
                if l is Light3D:
                        (l as Light3D).visible = true
                        var tw := create_tween()
                        tw.tween_property(l, "light_energy", l.get_meta("target_energy", 1.0), 0.6)
        var flick := get_tree().get_nodes_in_group("flicker_lights")
        for f in flick:
                if f.has_method("set_enabled"):
                        f.set_enabled(true)
        UIManager.show_subtitle(Localization.tr_key("story.power_note"), 4.0)


func _on_story_flag(flag: String) -> void:
        match flag:
                "entered_house":
                        _set_objective_key("objective.find_milik")
                        Game.register_checkpoint("entry")
                        Game.raise_aggression(1)
                        _apply_music_zone("ambient")


func _on_note_shown(_id: String) -> void:
        pass


func _set_objective_key(key: String) -> void:
        UIManager.set_objective(Localization.tr_key(key))


# ---------- monster state -> music ----------
func _on_monster_state(state: String) -> void:
        match state:
                "CHASE":
                        AudioManager.play_music("chase", 0.8, -6.0)
                "ATTACK":
                        AudioManager.play_music("chase", 0.3, -4.0)
                _:
                        if AudioManager.MUSIC.has(_saved_zone_music):
                                AudioManager.play_music(_saved_zone_music, 2.5, -10.0)


# ---------- intro cutscene ----------
func _start_intro() -> void:
        if friend == null:
                return
        friend.set_mode(0)  # FOLLOW
        Game.raise_aggression(0)
        _set_objective_key("objective.walk_house")
        UIManager.show_subtitle(Localization.tr_key("story.intro_1"), 4.0)
        await get_tree().create_timer(5.0).timeout
        if friend != null:
                UIManager.show_subtitle(Localization.tr_key("story.intro_2"), 4.0)


func trigger_intro_grab() -> void:
        if friend == null or _cameo_running:
                return
        _cameo_running = true
        var door := get_tree().get_first_node_in_group("front_door")
        if door == null:
                _cameo_running = false
                return
        var door_pos: Vector3 = door.global_position
        # friend walks to the door
        var tw := create_tween()
        var start := friend.global_position
        var near := door_pos + Vector3(0.8, 0, -1.4)
        tw.tween_property(friend, "global_position", near, 2.0)
        await tw.finished
        UIManager.show_subtitle(Localization.tr_key("story.intro_3"), 2.5)
        AudioManager.play_sfx_3d("scare_stinger", self, door_pos, "SFX", -2.0)
        AudioManager.play_monster_3d("monster_giggle", self, door_pos, 0.0)
        SettingsManager.vibrate(200, 1.0)
        # friend gets dragged inside
        var drag := create_tween()
        drag.tween_property(friend, "global_position", door_pos + Vector3(0, 0, 1.2), 1.4).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
        await drag.finished
        UIManager.show_subtitle(Localization.tr_key("story.intro_4"), 3.0)
        friend.set_mode(4)  # GONE (hidden until rescue)
        friend.visible = false
        # door slams
        if door.has_method("_toggle"):
                if not door.is_open:
                        door.is_open = true
                door._toggle()  # closes loudly
        await get_tree().create_timer(1.6).timeout
        # unlock front door for player
        if door.has_method("_try_unlock"):
                door.locked = false
        UIManager.show_subtitle(Localization.tr_key("story.enter_house"), 4.0)
        _set_objective_key("objective.enter_house")
        Game.set_flag("intro_done")
        _cameo_running = false


# ---------- cameo (first sight) ----------
func trigger_first_sight() -> void:
        if _cameo_running or Game.monster_active:
                return
        _cameo_running = true
        var marker := get_node_or_null("CameoPoints/CameoStart") as Node3D
        var exit_marker := get_node_or_null("CameoPoints/CameoExit") as Node3D
        if marker == null or exit_marker == null:
                _cameo_running = false
                return
        monster.process_mode = Node.PROCESS_MODE_DISABLED
        monster.global_position = marker.global_position
        var look := player.global_position - marker.global_position
        monster.rotation.y = atan2(-look.x, -look.z)
        monster.visible = true
        AudioManager.play_monster_3d("monster_giggle", self, marker.global_position, -4.0)
        UIManager.show_subtitle(Localization.tr_key("story.first_sight"), 3.5)
        await get_tree().create_timer(2.2).timeout
        var tw := create_tween()
        tw.tween_property(monster, "global_position", exit_marker.global_position, 3.2)
        await tw.finished
        monster.visible = false
        monster.global_position = _monster_home
        monster.process_mode = Node.PROCESS_MODE_INHERIT
        UIManager.vignette_pulse(0.25, 1.0)
        _cameo_running = false


# ---------- catch / respawn ----------
func on_player_caught() -> void:
        if _catch_ui_open:
                return
        _catch_ui_open = true
        Game.lose_game()
        player.caught()
        AudioManager.play_monster_3d("catch_scream", self, player.global_position, 2.0)
        AudioManager.play_sfx("scare_stinger", 0.0)
        UIManager.vignette_pulse(1.0, 2.5)
        SettingsManager.vibrate(300, 1.0)
        # zoom monster face-ish: quick shake
        var cam := player.get_node_or_null("Head/Camera3D") as Camera3D
        if cam != null:
                var tw := create_tween()
                for i in 8:
                        tw.tween_property(cam, "rotation:z", randf_range(-0.06, 0.06), 0.04)
                tw.tween_property(cam, "rotation:z", 0.0, 0.05)
        await get_tree().create_timer(1.4).timeout
        # fade out & show defeat overlay
        var overlay := _fade_overlay(true)
        await get_tree().create_timer(0.8).timeout
        _show_defeat_ui(overlay)


func _show_defeat_ui(overlay: ColorRect) -> void:
        var ui_scene: PackedScene = load("res://scenes/ui/defeat_overlay.tscn")
        var ui := ui_scene.instantiate()
        get_tree().current_scene.add_child(ui)
        ui.setup(overlay)


func _fade_overlay(black: bool) -> ColorRect:
        var existing := get_tree().current_scene.get_node_or_null("FadeOverlay") as ColorRect
        if existing != null:
                return existing
        var overlay := ColorRect.new()
        overlay.name = "FadeOverlay"
        overlay.color = Color(0, 0, 0, 0)
        overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
        overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
        get_tree().current_scene.add_child(overlay)
        var tw := create_tween()
        tw.tween_property(overlay, "color:a", 1.0 if black else 0.0, 0.7)
        return overlay


func respawn_player() -> void:
        _catch_ui_open = false
        var overlay := get_tree().current_scene.get_node_or_null("FadeOverlay") as ColorRect
        var spawn := _get_respawn_position()
        player.teleport_to(spawn)
        player.can_move = true
        player.controls_enabled = true
        monster.reset_to(_monster_home)
        monster.visible = true
        # remove fade
        if overlay != null:
                var tw := create_tween()
                tw.tween_property(overlay, "color:a", 0.0, 0.9)
                tw.tween_callback(overlay.queue_free)
        UIManager.show_message(Localization.tr_key("lose.hint"), 3.0)


func _get_respawn_position() -> Vector3:
        var key := Game.checkpoint_id
        var node := get_node_or_null("Checkpoints/" + key) as Node3D
        if node != null:
                return node.global_position
        return player.global_position


# ---------- cage / finale ----------
func on_cage_opened() -> void:
        if friend == null or _victory_open:
                return
        _victory_open = true
        Game.raise_aggression(3)
        friend.visible = true
        friend.set_mode(2)  # DRAGGED (walk out)
        var cage_inside := get_node_or_null("CagePoints/CageInside") as Node3D
        var cage_outside := get_node_or_null("CagePoints/CageOutside") as Node3D
        if cage_inside != null:
                friend.global_position = cage_inside.global_position
        UIManager.show_subtitle(Localization.tr_key("story.rescue_1"), 3.0)
        await get_tree().create_timer(1.0).timeout
        if cage_outside != null:
                var tw := create_tween()
                tw.tween_property(friend, "global_position", cage_outside.global_position, 2.0)
        await get_tree().create_timer(2.0).timeout
        if friend.has_method("celebrate"):
                friend.celebrate()
        UIManager.show_subtitle(Localization.tr_key("story.rescue_2"), 3.5)
        AudioManager.play_sfx("victory_stinger", -2.0)
        await get_tree().create_timer(2.5).timeout
        # final scare: evil Milik appears behind
        var scare_pos := player.global_position + Vector3(randf_range(-2, 2), 0, randf_range(-2, 2))
        monster.visible = true
        monster.global_position = scare_pos
        AudioManager.play_monster_3d("monster_growl_1", self, scare_pos, 4.0)
        AudioManager.play_sfx("scare_stinger", -4.0)
        UIManager.show_subtitle(Localization.tr_key("story.final_scare"), 2.5)
        UIManager.vignette_pulse(0.8, 1.6)
        SettingsManager.vibrate(200, 1.0)
        await get_tree().create_timer(1.2).timeout
        # friend + player run out: just fade to victory
        var overlay := _fade_overlay(true)
        await get_tree().create_timer(1.0).timeout
        var victory_scene: PackedScene = load("res://scenes/ui/victory_overlay.tscn")
        var v := victory_scene.instantiate()
        get_tree().current_scene.add_child(v)
        overlay.queue_free()


# ---------- triggers ----------
func fire_trigger(trigger_id: String) -> void:
        match trigger_id:
                "intro_grab":
                        trigger_intro_grab()
                "first_sight":
                        trigger_first_sight()
                "enter_house":
                        Game.set_flag("entered_house")
                        _apply_music_zone("ambient")
                        autosave_world()
                "basement_enter":
                        Game.register_checkpoint("basement")
                        Game.raise_aggression(2)
                        AudioManager.play_ambient_3d("basement_hum", self, monster.global_position, -8.0)
                "cage_room_enter":
                        Game.register_checkpoint("cage_room")
                        UIManager.show_message(Localization.tr_key("objective.cage_room"), 3.5)


# ---------- saving ----------
func autosave_world() -> void:
        var payload := {}
        payload["player"] = {"pos": [player.global_position.x, player.global_position.y, player.global_position.z]}
        payload["world"] = serialize_world()
        Game.autosave(payload)


func serialize_world() -> Dictionary:
        var world := {"doors": {}, "puzzles": {}, "pickups_removed": []}
        for door in get_tree().get_nodes_in_group("doors"):
                world["doors"][door.door_id] = door.is_open
        for cab in get_tree().get_nodes_in_group("symbol_cabinets"):
                world["puzzles"][cab.cabinet_id] = cab.serialize_state()
        for bp in get_tree().get_nodes_in_group("breakers"):
                world["puzzles"][bp.panel_id] = bp.serialize_state()
        for gate in get_tree().get_nodes_in_group("cage_gates"):
                world["puzzles"][gate.gate_id] = gate.serialize_state()
        for gen in get_tree().get_nodes_in_group("generator"):
                world["puzzles"][gen.generator_id] = {"running": gen.running}
        for pk in get_tree().get_nodes_in_group("pickups"):
                if pk.get("_collected") == true:
                        world["pickups_removed"].append(str(pk.get_path()))
        return world


func _restore_world() -> void:
        var data := _pending_restore
        if data.is_empty():
                return
        var world: Dictionary = data.get("world", {})
        var doors: Dictionary = world.get("doors", {})
        for door in get_tree().get_nodes_in_group("doors"):
                var st: Variant = doors.get(door.door_id, null)
                if st != null:
                        door.is_open = bool(st)
                        door.pivot.rotation_degrees.y = door.open_angle_deg if door.is_open else 0.0
                        _on_door_toggled(door.door_id, door.is_open)
        var puzzles: Dictionary = world.get("puzzles", {})
        for cab in get_tree().get_nodes_in_group("symbol_cabinets"):
                if puzzles.has(cab.cabinet_id):
                        cab.restore_state(puzzles[cab.cabinet_id])
        for bp in get_tree().get_nodes_in_group("breakers"):
                if puzzles.has(bp.panel_id):
                        bp.restore_state(puzzles[bp.panel_id])
        for gate in get_tree().get_nodes_in_group("cage_gates"):
                if puzzles.has(gate.gate_id):
                        gate.restore_state(puzzles[gate.gate_id])
        for gen in get_tree().get_nodes_in_group("generator"):
                if puzzles.has(gen.generator_id) and puzzles[gen.generator_id].get("running", false):
                        gen.running = true
                        if gen.get("hum_player") != null:
                                gen.hum_player.play()
        var ppos: Array = data.get("player", {}).get("pos", [])
        if ppos.size() == 3 and player != null:
                player.teleport_to(Vector3(ppos[0], ppos[1], ppos[2]))
        # if power was on, apply lights
        if Game.power_on:
                _on_power_on()
        # friend placement
        if Game.has_flag("intro_done"):
                friend.set_mode(3)
                friend.visible = false
                var cage_inside := get_node_or_null("CagePoints/CageInside") as Node3D
                if cage_inside != null:
                        friend.global_position = cage_inside.global_position
                        friend.visible = true
                        friend.set_mode(1)
        # objective text by progress
        if Game.has_flag("breaker_ok"):
                _set_objective_key("objective.fix_cage")
        elif Game.power_on:
                _set_objective_key("objective.find_breaker")
        elif Game.has_flag("entered_house"):
                _set_objective_key("objective.find_milik")
