extends Area3D
## Story trigger: fires level.fire_trigger(trigger_id) once (or repeatedly).

@export var trigger_id: String = ""
@export var one_shot: bool = true

var _fired := false


func _ready() -> void:
	body_entered.connect(_on_body)


func _on_body(body: Node3D) -> void:
	if one_shot and _fired:
		return
	if body.is_in_group("player"):
		_fired = true
		var level := get_tree().get_first_node_in_group("level")
		if level != null and level.has_method("fire_trigger"):
			level.fire_trigger(trigger_id)
