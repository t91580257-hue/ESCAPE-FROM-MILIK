extends Area3D
## Music/ambience zone: changes music when the player enters.

@export var music_zone: String = "ambient"


func _ready() -> void:
	body_entered.connect(_on_body)


func _on_body(body: Node3D) -> void:
	if body.is_in_group("player"):
		var level := get_tree().get_first_node_in_group("level")
		if level != null and level.has_method("_apply_music_zone"):
			level._apply_music_zone(music_zone)
