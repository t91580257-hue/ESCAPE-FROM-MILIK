extends CharacterBody3D
## Real Milik: yard companion, caged friend, rescue finale.

enum Mode { FOLLOW, CAGED, DRAGGED, SAVED, GONE }

@export var model_scale: float = 0.22

var mode: int = Mode.FOLLOW
var target: Node3D = null
var _model_root: Node3D
var _anim: AnimationPlayer = null
var _time := 0.0
var _hop_timer := 0.0
const FOLLOW_SPEED := 2.2
const GRAVITY := 14.0


func _ready() -> void:
	add_to_group("friend_milik")
	_instantiate_model()


func _instantiate_model() -> void:
	var path := "res://models/characters/milik_friendly.glb"
	if not ResourceLoader.exists(path):
		push_warning("MilikFriend: model missing")
		return
	var scene: PackedScene = load(path)
	_model_root = Node3D.new()
	add_child(_model_root)
	_model_root.rotation_degrees = Vector3(-90, 0, 0)
	_model_root.scale = Vector3.ONE * model_scale
	var inst := scene.instantiate()
	_model_root.add_child(inst)
	_anim = inst.find_child("AnimationPlayer", true, false)
	if _anim != null:
		var walk_name := ""
		for cand in ["Walk_Loop", "Walk"]:
			if _anim.has_animation(cand):
				walk_name = cand
				break
		if walk_name != "":
			_anim.get_animation(walk_name).loop_mode = Animation.LOOP_LINEAR
			_anim.play(walk_name)
			_anim.speed_scale = 0.0


func set_mode(m: int) -> void:
	mode = m


func is_caged() -> bool:
	return mode == Mode.CAGED


func _physics_process(delta: float) -> void:
	_time += delta
	match mode:
		Mode.FOLLOW, Mode.SAVED:
			_process_follow(delta)
		Mode.CAGED:
			velocity = Vector3.ZERO
			_process_idle(delta)
		Mode.DRAGGED, Mode.GONE:
			velocity = Vector3.ZERO
	var walking := Vector2(velocity.x, velocity.z).length() > 0.3
	if _anim != null:
		_anim.speed_scale = lerpf(_anim.speed_scale, 1.3 if walking else 0.0, 8.0 * delta)
	# hop while idle (cute)
	if mode == Mode.FOLLOW and not walking:
		_hop_timer -= delta
		if _hop_timer <= 0.0:
			_hop_timer = randf_range(2.5, 5.0)
			var tw := create_tween()
			tw.tween_property(_model_root, "position:y", 0.14, 0.14).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
			tw.tween_property(_model_root, "position:y", 0.0, 0.16).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)


func _process_follow(delta: float) -> void:
	if target == null or not is_instance_valid(target):
		if not is_on_floor():
			velocity.y -= GRAVITY * delta
		move_and_slide()
		return
	var to_target := target.global_position - global_position
	to_target.y = 0
	var dist := to_target.length()
	if dist > 1.6:
		var dir := to_target.normalized()
		velocity.x = dir.x * FOLLOW_SPEED
		velocity.z = dir.z * FOLLOW_SPEED
		rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), 6.0 * delta)
	else:
		velocity.x = 0
		velocity.z = 0
		# look at player
		var dir := to_target.normalized()
		rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), 3.0 * delta)
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	else:
		velocity.y = 0
	move_and_slide()


func _process_idle(_delta: float) -> void:
	# subtle shiver in the cage
	_model_root.rotation_degrees.z = sin(_time * 8.0) * 0.6


func set_target(t: Node3D) -> void:
	target = t


func celebrate() -> void:
	var tw := create_tween()
	tw.tween_property(_model_root, "position:y", 0.3, 0.18).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_property(_model_root, "position:y", 0.0, 0.2).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tw.tween_property(_model_root, "rotation:y", TAU, 0.6)
	tw.tween_property(_model_root, "rotation:y", 0.0, 0.01)
