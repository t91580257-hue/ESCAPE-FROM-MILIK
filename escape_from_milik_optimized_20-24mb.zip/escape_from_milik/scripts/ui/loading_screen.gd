extends Control
## Loading screen: animated indicator, title, tips, evil Milik image feel.

var progress_bar: ProgressBar
var tip_label: Label
var _fake := 0.0
var _done := false


func _ready() -> void:
	theme = UITheme.build()
	set_anchors_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = Color(0.02, 0.02, 0.035)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var vb := VBoxContainer.new()
	vb.set_anchors_preset(Control.PRESET_CENTER)
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_theme_constant_override("separation", 26)
	vb.offset_left = -400
	vb.offset_right = 400
	vb.offset_top = -260
	vb.offset_bottom = 260
	add_child(vb)

	var title := UITheme.title_label(Localization.tr_key("game.title"), 58)
	vb.add_child(title)

	var load_lbl := Label.new()
	load_lbl.text = Localization.tr_key("load.title")
	load_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	load_lbl.add_theme_font_size_override("font_size", 28)
	load_lbl.add_theme_color_override("font_color", Color(0.6, 0.58, 0.55))
	vb.add_child(load_lbl)

	progress_bar = ProgressBar.new()
	progress_bar.min_value = 0
	progress_bar.max_value = 100
	progress_bar.value = 0
	progress_bar.custom_minimum_size = Vector2(640, 18)
	progress_bar.show_percentage = false
	vb.add_child(progress_bar)

	tip_label = Label.new()
	tip_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tip_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tip_label.custom_minimum_size = Vector2(640, 80)
	tip_label.add_theme_font_size_override("font_size", 22)
	tip_label.add_theme_color_override("font_color", Color(0.65, 0.6, 0.55))
	var tips := ["load.tip1", "load.tip2", "load.tip3", "load.tip4", "load.tip5"]
	tip_label.text = Localization.tr_key(tips[randi() % tips.size()])
	vb.add_child(tip_label)


func start_fake_progress() -> void:
	_done = false
	var tw := create_tween()
	tw.tween_method(_set_fake, 0.0, 88.0, 0.8)


func _set_fake(v: float) -> void:
	if not _done:
		progress_bar.value = v


func finish_and_fade() -> void:
	_done = true
	progress_bar.value = 100
	var tw := create_tween()
	tw.tween_property(self, "modulate:a", 0.0, 0.7)
	tw.tween_callback(func(): visible = false)
