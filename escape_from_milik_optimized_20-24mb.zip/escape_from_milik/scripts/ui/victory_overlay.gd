extends Control
## Victory overlay: "YOU SAVED MILIK!" + stats + play again / main menu.


func _ready() -> void:
	theme = UITheme.build()
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_build()
	AudioManager.play_music("victory", 1.0, -8.0)


func _build() -> void:
	var bg := ColorRect.new()
	bg.color = Color(0.02, 0.05, 0.04, 0.94)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var vb := VBoxContainer.new()
	vb.set_anchors_preset(Control.PRESET_CENTER)
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_theme_constant_override("separation", 22)
	vb.offset_left = -460
	vb.offset_right = 460
	vb.offset_top = -260
	vb.offset_bottom = 260
	add_child(vb)

	var title := UITheme.title_label(Localization.tr_key("win.title"), 56)
	title.add_theme_color_override("font_color", Color(0.3, 0.85, 0.55))
	var tw := create_tween().set_loops()
	tw.tween_property(title, "modulate", Color(0.8, 1.3, 0.9), 1.0)
	tw.tween_property(title, "modulate", Color(0.5, 1.0, 0.7), 1.0)
	vb.add_child(title)

	var stats := Label.new()
	stats.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	stats.add_theme_font_size_override("font_size", 26)
	stats.text = "%s\n%s %d\n%s %d\n%s %d" % [
		Localization.tr_key("win.time") % Game.format_time(Game.run_time),
		Localization.tr_key("win.items"), Game.items_collected_total,
		Localization.tr_key("win.puzzles"), Game.puzzles_solved.size(),
		Localization.tr_key("win.deaths"), Game.times_caught,
	]
	stats.add_theme_color_override("font_color", Color(0.85, 0.85, 0.9))
	vb.add_child(stats)

	var again := UITheme.menu_button(Localization.tr_key("menu.play_again"), 30)
	again.pressed.connect(func():
		SaveManager.delete_save()
		Game.start_new_game(Game.difficulty)
		SceneManager.restart_game())
	vb.add_child(again)

	var menu := UITheme.menu_button(Localization.tr_key("menu.to_main_menu"), 30)
	menu.pressed.connect(func():
		SaveManager.delete_save()
		SceneManager.to_main_menu())
	vb.add_child(menu)
