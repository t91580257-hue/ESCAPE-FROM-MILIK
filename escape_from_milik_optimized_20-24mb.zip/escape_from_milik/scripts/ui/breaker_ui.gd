extends Control
## Breaker panel UI: flip levers in the note's order (2-1-3).

var flipped: Array = []


func _ready() -> void:
	theme = UITheme.build()
	set_anchors_preset(Control.PRESET_FULL_RECT)
	visible = false
	_build()


func _build() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

	var panel := PanelContainer.new()
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.custom_minimum_size = Vector2(560, 480)
	add_child(panel)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 18)
	panel.add_child(vb)

	vb.add_child(UITheme.title_label(Localization.tr_key("world.breaker"), 34))
	var hint := Label.new()
	hint.text = Localization.tr_key("world.breaker_hint")
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.add_theme_font_size_override("font_size", 22)
	vb.add_child(hint)

	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 20)
	hb.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_child(hb)

	for i in range(1, 4):
		var b := Button.new()
		b.text = str(i)
		b.name = "Lever%d" % i
		b.custom_minimum_size = Vector2(130, 150)
		b.add_theme_font_size_override("font_size", 44)
		b.pressed.connect(_on_lever.bind(i))
		hb.add_child(b)


func open_panel() -> void:
	visible = true


func _on_lever(i: int) -> void:
	if flipped.has(i):
		return
	flipped.append(i)
	EventBus.breaker_flipped.emit("basement_breaker", i)
	var b := find_child("Lever%d" % i, true, false) as Button
	if b != null:
		b.disabled = true
	if flipped.size() >= 3:
		var tw := create_tween()
		tw.tween_interval(0.6)
		tw.tween_callback(func():
			flipped.clear()
			if visible:
				visible = false
				for j in range(1, 4):
					var bb := find_child("Lever%d" % j, true, false) as Button
					if bb != null:
						bb.disabled = false)


func _unhandled_input(event: InputEvent) -> void:
	if visible and event.is_action_pressed("ui_cancel"):
		visible = false
