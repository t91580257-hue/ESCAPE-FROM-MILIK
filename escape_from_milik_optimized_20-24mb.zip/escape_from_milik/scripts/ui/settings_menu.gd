extends Control
## Settings menu: Graphics / Audio / Controls / Gameplay tabs.
## Works standalone (from main menu) and embedded (from pause).

signal closed

var tabs: TabContainer
var _standalone := true


func _ready() -> void:
	theme = UITheme.build()
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_standalone = not _inside_pause()
	_build()
	visible = not _standalone or true


func _inside_pause() -> bool:
	var p := get_parent()
	while p != null:
		if p.is_in_group("pause_menu"):
			return true
		p = p.get_parent()
	return false


func _build() -> void:
	var bg := ColorRect.new()
	bg.color = Color(0.02, 0.02, 0.04, 0.98)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var vb := VBoxContainer.new()
	vb.set_anchors_preset(Control.PRESET_FULL_RECT)
	vb.offset_left = 60
	vb.offset_right = -60
	vb.offset_top = 30
	vb.offset_bottom = -30
	vb.add_theme_constant_override("separation", 14)
	add_child(vb)

	vb.add_child(UITheme.title_label(Localization.tr_key("set.title"), 44))

	tabs = TabContainer.new()
	tabs.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(tabs)
	tabs.add_child(_graphics_tab())
	tabs.add_child(_audio_tab())
	tabs.add_child(_controls_tab())
	tabs.add_child(_gameplay_tab())
	_set_tab_names()

	var hb := HBoxContainer.new()
	hb.alignment = BoxContainer.ALIGNMENT_CENTER
	hb.add_theme_constant_override("separation", 20)
	vb.add_child(hb)

	var apply_b := UITheme.menu_button(Localization.tr_key("menu.apply"), 26)
	apply_b.pressed.connect(_on_apply)
	hb.add_child(apply_b)

	var reset_b := UITheme.menu_button(Localization.tr_key("menu.reset"), 26)
	reset_b.pressed.connect(_on_reset)
	hb.add_child(reset_b)

	var back_b := UITheme.menu_button(Localization.tr_key("menu.back"), 26)
	back_b.pressed.connect(_on_back)
	hb.add_child(back_b)


func _set_tab_names() -> void:
	tabs.set_tab_title(0, Localization.tr_key("set.graphics"))
	tabs.set_tab_title(1, Localization.tr_key("set.audio"))
	tabs.set_tab_title(2, Localization.tr_key("set.controls"))
	tabs.set_tab_title(3, Localization.tr_key("set.gameplay"))


func _tab() -> VBoxContainer:
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	return vb


func _row(parent: Control, label_key: String, widget: Control) -> HBoxContainer:
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 16)
	var l := Label.new()
	l.text = Localization.tr_key(label_key)
	l.custom_minimum_size = Vector2(340, 40)
	l.add_theme_font_size_override("font_size", 24)
	hb.add_child(l)
	widget.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.add_child(widget)
	parent.add_child(hb)
	return hb


func _option(values: Array, current: Variant, cb: Callable) -> OptionButton:
	var ob := OptionButton.new()
	for v in values:
		ob.add_item(str(v))
	var idx := values.find(current)
	if idx >= 0:
		ob.selected = idx
	ob.item_selected.connect(func(i: int): cb.call(values[i]))
	return ob


func _slider(min_v: float, max_v: float, current: float, cb: Callable, step: float = 0.05) -> HSlider:
	var s := HSlider.new()
	s.min_value = min_v
	s.max_value = max_v
	s.step = step
	s.value = current
	s.custom_minimum_size = Vector2(300, 40)
	s.value_changed.connect(cb)
	return s


# ---------- tabs ----------
func _graphics_tab() -> VBoxContainer:
	var vb := _tab()
	var qualities := ["low", "medium", "high", "ultra"]
	var qnames := {
		"low": Localization.tr_key("set.low"), "medium": Localization.tr_key("set.medium"),
		"high": Localization.tr_key("set.high"), "ultra": Localization.tr_key("set.ultra"),
	}
	var qbtn := OptionButton.new()
	for q in qualities:
		qbtn.add_item(qnames[q])
	qbtn.selected = qualities.find(SettingsManager.quality)
	qbtn.item_selected.connect(func(i: int):
		SettingsManager.set_quality(qualities[i]))
	_row(vb, "set.quality", qbtn)

	var shadows := _option([0, 1, 2], SettingsManager.shadow_quality, func(v): SettingsManager.shadow_quality = v)
	_row(vb, "set.shadow_quality", shadows)

	var dist := _slider(30, 110, SettingsManager.draw_distance, func(v): SettingsManager.draw_distance = v, 5.0)
	_row(vb, "set.draw_distance", dist)

	var aa := _option([Localization.tr_key("set.off"), "2x", "4x"], 1 if SettingsManager.msaa_level >= 1 else 0, func(v):
		SettingsManager.msaa_level = 0 if v == 0 else (1 if v == 1 else 2))
	_row(vb, "set.antialiasing", aa)

	var bloom := _option([Localization.tr_key("set.off"), Localization.tr_key("set.on")], 1 if SettingsManager.bloom else 0, func(v):
		SettingsManager.bloom = v == 1)
	_row(vb, "set.bloom", bloom)

	var ssao := _option([Localization.tr_key("set.off"), Localization.tr_key("set.on")], 1 if SettingsManager.ssao else 0, func(v):
		SettingsManager.ssao = v == 1)
	_row(vb, "set.ssao", ssao)

	var fog := _option([Localization.tr_key("set.off"), Localization.tr_key("set.on")], 1 if SettingsManager.fog_effects else 0, func(v):
		SettingsManager.fog_effects = v == 1)
	_row(vb, "set.fog", fog)

	var fps := _option([Localization.tr_key("set.fps30"), Localization.tr_key("set.fps60"), Localization.tr_key("set.fps120"), Localization.tr_key("set.nolimit")], [30, 60, 120, 0].find(SettingsManager.fps_limit), func(i: int):
		SettingsManager.fps_limit = [30, 60, 120, 0][i])
	_row(vb, "set.fps_limit", fps)
	return vb


func _audio_tab() -> VBoxContainer:
	var vb := _tab()
	_row(vb, "set.vol_master", _slider(0, 1, SettingsManager.vol_master, func(v): SettingsManager.vol_master = v))
	_row(vb, "set.vol_music", _slider(0, 1, SettingsManager.vol_music, func(v): SettingsManager.vol_music = v))
	_row(vb, "set.vol_sfx", _slider(0, 1, SettingsManager.vol_sfx, func(v): SettingsManager.vol_sfx = v))
	_row(vb, "set.vol_monster", _slider(0, 1, SettingsManager.vol_monster, func(v): SettingsManager.vol_monster = v))
	_row(vb, "set.vol_ambient", _slider(0, 1, SettingsManager.vol_ambient, func(v): SettingsManager.vol_ambient = v))
	return vb


func _controls_tab() -> VBoxContainer:
	var vb := _tab()
	_row(vb, "set.sensitivity", _slider(0.3, 3.0, SettingsManager.sensitivity, func(v): SettingsManager.sensitivity = v, 0.1))
	_row(vb, "set.joystick_size", _slider(0.6, 1.6, SettingsManager.joystick_size, func(v): SettingsManager.joystick_size = v, 0.1))
	_row(vb, "set.button_opacity", _slider(0.2, 1.0, SettingsManager.button_opacity, func(v): SettingsManager.button_opacity = v, 0.05))
	var inv := _option([Localization.tr_key("set.off"), Localization.tr_key("set.on")], 1 if SettingsManager.invert_y else 0, func(v):
		SettingsManager.invert_y = v == 1)
	_row(vb, "set.invert_y", inv)
	return vb


func _gameplay_tab() -> VBoxContainer:
	var vb := _tab()
	var lang := _option(["Русский", "English"], ["ru", "en"].find(SettingsManager.language), func(i: int):
		SettingsManager.language = ["ru", "en"][i])
	_row(vb, "set.language", lang)
	var vib := _option([Localization.tr_key("set.off"), Localization.tr_key("set.on")], 1 if SettingsManager.vibration else 0, func(v):
		SettingsManager.vibration = v == 1)
	_row(vb, "set.vibration", vib)
	var subs := _option([Localization.tr_key("set.off"), Localization.tr_key("set.on")], 1 if SettingsManager.subtitles else 0, func(v):
		SettingsManager.subtitles = v == 1)
	_row(vb, "set.subtitles", subs)
	var hints := _option([Localization.tr_key("set.off"), Localization.tr_key("set.on")], 1 if SettingsManager.hints else 0, func(v):
		SettingsManager.hints = v == 1)
	_row(vb, "set.hints", hints)
	return vb


# ---------- actions ----------
func _on_apply() -> void:
	SettingsManager.apply_all()
	SettingsManager.save_settings()
	UIManager.show_message(Localization.tr_key("set.applied"), 2.0)
	AudioManager.ui_click()
	var tc := get_tree().get_first_node_in_group("touch_controls")
	if tc != null and tc.has_method("apply_settings"):
		tc.apply_settings()
	closed.emit()


func _on_reset() -> void:
	SettingsManager.reset_to_defaults()
	AudioManager.ui_back()
	# rebuild tab values
	for c in tabs.get_children():
		c.queue_free()
	tabs.add_child(_graphics_tab())
	tabs.add_child(_audio_tab())
	tabs.add_child(_controls_tab())
	tabs.add_child(_gameplay_tab())
	_set_tab_names()
	closed.emit()


func _on_back() -> void:
	SettingsManager.apply_all()
	SettingsManager.save_settings()
	AudioManager.ui_back()
	if _inside_pause():
		visible = false
		closed.emit()
	else:
		SceneManager.goto_scene("main_menu")
