extends Control
## Symbols UI: press 4 symbol buttons in the right order.

const SYMBOL_GLYPHS := ["★", "☾", "☀", "♥", "▲", "■"]

var _entered: Array = []


func _ready() -> void:
	theme = UITheme.build()
	set_anchors_preset(Control.PRESET_FULL_RECT)
	visible = false
	_build()


func _build() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

	var panel := PanelContainer.new()
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.custom_minimum_size = Vector2(720, 460)
	add_child(panel)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 18)
	panel.add_child(vb)

	vb.add_child(UITheme.title_label(Localization.tr_key("world.symbol_cabinet"), 34))
	var hint := Label.new()
	hint.text = Localization.tr_key("world.symbol_hint")
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.add_theme_font_size_override("font_size", 22)
	hint.add_theme_color_override("font_color", Color(0.8, 0.8, 0.85))
	vb.add_child(hint)

	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 14)
	grid.add_theme_constant_override("v_separation", 14)
	vb.add_child(grid)

	for i in SYMBOL_GLYPHS.size():
		var b := Button.new()
		b.text = SYMBOL_GLYPHS[i]
		b.custom_minimum_size = Vector2(150, 110)
		b.add_theme_font_size_override("font_size", 48)
		b.pressed.connect(_on_symbol.bind(i))
		grid.add_child(b)

	var entered_label := Label.new()
	entered_label.name = "EnteredLabel"
	entered_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	entered_label.add_theme_font_size_override("font_size", 30)
	entered_label.add_theme_color_override("font_color", Color(1, 0.9, 0.5))
	vb.add_child(entered_label)


func open_symbols() -> void:
	_entered.clear()
	_update()
	visible = true


func _on_symbol(i: int) -> void:
	AudioManager.play_sfx("puzzle_click", -4.0)
	_entered.append(i)
	if _entered.size() >= 4:
		EventBus.symbols_entered.emit("living_cabinet", _entered.duplicate())
		if _entered != [2, 0, 3, 1]:
			# will be reset on wrong; small delay
			var tw := create_tween()
			tw.tween_interval(0.4)
			tw.tween_callback(func():
				if visible:
					_entered.clear()
					_update())
		else:
			visible = false
	_update()


func _update() -> void:
	var lbl := find_child("EnteredLabel", true, false) as Label
	if lbl != null:
		var glyphs := ""
		for i in _entered:
			glyphs += SYMBOL_GLYPHS[i] + " "
		lbl.text = glyphs


func _unhandled_input(event: InputEvent) -> void:
	if visible and event.is_action_pressed("ui_cancel"):
		visible = false
