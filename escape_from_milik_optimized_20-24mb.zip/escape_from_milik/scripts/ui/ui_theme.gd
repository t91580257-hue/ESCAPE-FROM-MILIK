class_name UITheme
extends RefCounted
## UITheme: runtime theme builder — horror style, Cyrillic-safe font.

const FONT_PATH := "res://ui/fonts/font_main.ttf"
const FONT_BOLD_PATH := "res://ui/fonts/font_main.ttf"

const COL_BG := Color(0.03, 0.03, 0.05, 0.92)
const COL_PANEL := Color(0.06, 0.06, 0.09, 0.96)
const COL_TEXT := Color(0.92, 0.90, 0.86)
const COL_DIM := Color(0.55, 0.52, 0.5)
const COL_ACCENT := Color(0.78, 0.12, 0.10)
const COL_ACCENT2 := Color(0.2, 0.65, 0.55)
const COL_BTN := Color(0.10, 0.10, 0.14, 0.9)

static var _font: FontFile = null


static func get_font() -> FontFile:
	if _font == null:
		if ResourceLoader.exists(FONT_PATH):
			_font = load(FONT_PATH)
		else:
			_font = ThemeDB.fallback_font
	return _font


static func flat_style(bg: Color, border: Color = Color.TRANSPARENT, border_w: int = 0, radius: int = 10) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.set_corner_radius_all(radius)
	sb.content_margin_left = 22
	sb.content_margin_right = 22
	sb.content_margin_top = 12
	sb.content_margin_bottom = 12
	if border_w > 0:
		sb.border_color = border
		sb.set_border_width_all(border_w)
	return sb


static func build() -> Theme:
	var theme := Theme.new()
	var font := get_font()
	if font != null:
		theme.default_font = font
	theme.default_font_size = 24
	# Label
	theme.set_color("font_color", "Label", COL_TEXT)
	theme.set_font_size("font_size", "Label", 24)
	# Button
	theme.set_color("font_color", "Button", COL_TEXT)
	theme.set_color("font_hover_color", "Button", Color(1, 0.85, 0.7))
	theme.set_color("font_pressed_color", "Button", COL_ACCENT)
	theme.set_color("font_disabled_color", "Button", COL_DIM)
	theme.set_font_size("font_size", "Button", 26)
	theme.set_stylebox("normal", "Button", flat_style(COL_BTN, Color(0.35, 0.12, 0.1), 2, 12))
	theme.set_stylebox("hover", "Button", flat_style(Color(0.16, 0.10, 0.10, 0.95), COL_ACCENT, 2, 12))
	theme.set_stylebox("pressed", "Button", flat_style(Color(0.24, 0.07, 0.06, 0.98), COL_ACCENT, 2, 12))
	theme.set_stylebox("disabled", "Button", flat_style(Color(0.08, 0.08, 0.1, 0.6), Color(0.2, 0.2, 0.22), 1, 12))
	theme.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	# Panel
	theme.set_stylebox("panel", "Panel", flat_style(COL_PANEL, Color(0.25, 0.08, 0.08, 0.8), 2, 14))
	theme.set_stylebox("panel", "PanelContainer", flat_style(COL_PANEL, Color(0.25, 0.08, 0.08, 0.8), 2, 14))
	# LineEdit
	theme.set_color("font_color", "LineEdit", COL_TEXT)
	theme.set_stylebox("normal", "LineEdit", flat_style(Color(0.02, 0.02, 0.04, 0.95), Color(0.3, 0.3, 0.35), 1, 8))
	theme.set_font_size("font_size", "LineEdit", 34)
	# HSlider
	theme.set_stylebox("slider", "HSlider", flat_style(Color(0.2, 0.2, 0.24), Color.TRANSPARENT, 0, 4))
	theme.set_stylebox("grabber_area", "HSlider", flat_style(COL_ACCENT2, Color.TRANSPARENT, 0, 4))
	# ProgressBar
	theme.set_stylebox("background", "ProgressBar", flat_style(Color(0.05, 0.05, 0.08, 0.8), Color.TRANSPARENT, 0, 6))
	theme.set_stylebox("fill", "ProgressBar", flat_style(COL_ACCENT2, Color.TRANSPARENT, 0, 6))
	return theme


static func title_label(text: String, size: int = 64) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_override("font", get_font())
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", COL_ACCENT)
	l.add_theme_constant_override("outline_size", 12)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	return l


static func menu_button(text: String, font_size: int = 30) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_override("font", get_font())
	b.add_theme_font_size_override("font_size", font_size)
	b.custom_minimum_size = Vector2(420, 64)
	b.mouse_entered.connect(func(): AudioManager.ui_hover())
	b.pressed.connect(func(): AudioManager.ui_click())
	return b
