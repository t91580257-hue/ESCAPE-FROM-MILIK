extends Control
## Pause menu: resume / restart / settings / main menu. Stops game time.

var panel: PanelContainer
var settings_holder: Control


func _ready() -> void:
	add_to_group("pause_menu")
	theme = UITheme.build()
	set_anchors_preset(Control.PRESET_FULL_RECT)
	visible = false
	_build()
	process_mode = Node.PROCESS_MODE_ALWAYS


func _build() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

	panel = PanelContainer.new()
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.custom_minimum_size = Vector2(520, 480)
	add_child(panel)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 18)
	panel.add_child(vb)

	var title := UITheme.title_label(Localization.tr_key("hud.paused"), 52)
	vb.add_child(title)

	vb.add_child(_btn(Localization.tr_key("menu.resume"), func():
		close_pause()))
	vb.add_child(_btn(Localization.tr_key("menu.restart"), func():
		close_pause()
		SceneManager.restart_game()))
	vb.add_child(_btn(Localization.tr_key("menu.settings"), func():
		settings_holder.visible = true))
	vb.add_child(_btn(Localization.tr_key("menu.to_main_menu"), func():
		Game.autosave()
		SceneManager.to_main_menu()))

	# embedded settings panel
	settings_holder = Control.new()
	settings_holder.set_anchors_preset(Control.PRESET_FULL_RECT)
	settings_holder.visible = false
	var sscript := load("res://scripts/ui/settings_menu.gd")
	settings_holder.set_script(sscript)
	add_child(settings_holder)


func _btn(text: String, cb: Callable) -> Button:
	var b := UITheme.menu_button(text)
	b.pressed.connect(cb)
	return b


func open_pause() -> void:
	if visible:
		return
	visible = true
	get_tree().paused = true
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	AudioManager.ui_click()


func close_pause() -> void:
	visible = false
	settings_holder.visible = false
	get_tree().paused = false


func bind_level(_level: Node) -> void:
	pass
