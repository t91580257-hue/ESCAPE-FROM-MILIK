extends Control
## Keypad UI: numeric code entry (pantry lock).

var display: Label
var _code := ""


func _ready() -> void:
	theme = UITheme.build()
	set_anchors_preset(Control.PRESET_FULL_RECT)
	visible = false
	_build()


func _build() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

	var panel := PanelContainer.new()
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.custom_minimum_size = Vector2(460, 620)
	add_child(panel)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 16)
	panel.add_child(vb)

	vb.add_child(UITheme.title_label(Localization.tr_key("world.keypad_hint"), 34))

	display = Label.new()
	display.text = "_ _ _"
	display.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	display.add_theme_font_size_override("font_size", 54)
	display.add_theme_color_override("font_color", Color(0.5, 1.0, 0.6))
	vb.add_child(display)

	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	vb.add_child(grid)

	for n in range(1, 10):
		grid.add_child(_num_btn(str(n)))
	grid.add_child(_num_btn("C"))
	grid.add_child(_num_btn("0"))
	grid.add_child(_num_btn("OK"))


func _num_btn(txt: String) -> Button:
	var b := Button.new()
	b.text = txt
	b.custom_minimum_size = Vector2(120, 92)
	b.add_theme_font_size_override("font_size", 36)
	b.pressed.connect(_on_press.bind(txt))
	return b


func open_keypad() -> void:
	_code = ""
	_update_display()
	visible = true


func _update_display() -> void:
	var parts := _code.split("")
	var texts := ["_", "_", "_"]
	for i in parts.size():
		if i < 3:
			texts[i] = parts[i]
	display.text = " ".join(texts)


func _on_press(txt: String) -> void:
	AudioManager.play_sfx("puzzle_click", -6.0)
	match txt:
		"C":
			_code = ""
			_update_display()
		"OK":
			if _code.length() == 3:
				EventBus.keypad_entered.emit("pantry", _code)
				visible = false
			else:
				AudioManager.play_sfx("puzzle_error", -8.0)
		_:
			if _code.length() < 3:
				_code += txt
				_update_display()


func _unhandled_input(event: InputEvent) -> void:
	if visible and event.is_action_pressed("ui_cancel"):
		visible = false
