extends Control
## About menu.


func _ready() -> void:
	theme = UITheme.build()
	set_anchors_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = Color(0.02, 0.02, 0.04)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var vb := VBoxContainer.new()
	vb.set_anchors_preset(Control.PRESET_CENTER)
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_theme_constant_override("separation", 24)
	vb.offset_left = -480
	vb.offset_right = 480
	vb.offset_top = -280
	vb.offset_bottom = 280
	add_child(vb)

	vb.add_child(UITheme.title_label(Localization.tr_key("about.title"), 46))

	var text := Label.new()
	text.text = Localization.tr_key("about.text")
	text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	text.add_theme_font_size_override("font_size", 23)
	vb.add_child(text)

	var back := UITheme.menu_button(Localization.tr_key("menu.back"), 26)
	back.pressed.connect(func():
		AudioManager.ui_back()
		SceneManager.goto_scene("main_menu"))
	vb.add_child(back)
