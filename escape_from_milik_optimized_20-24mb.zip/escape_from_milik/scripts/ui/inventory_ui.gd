extends Control
## Inventory UI: grid of slots, item info, use/combine actions.

var panel: PanelContainer
var grid: GridContainer
var info_title: Label
var info_desc: Label
var selected := -1
var _combine_mode := false
var _combine_first := -1


func _ready() -> void:
	add_to_group("inventory_ui")
	theme = UITheme.build()
	set_anchors_preset(Control.PRESET_FULL_RECT)
	visible = false
	_build()
	EventBus.inventory_changed.connect(_refresh)


func _build() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.55)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

	panel = PanelContainer.new()
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.custom_minimum_size = Vector2(760, 560)
	add_child(panel)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	panel.add_child(vb)

	var title := UITheme.title_label(Localization.tr_key("hud.inventory"), 42)
	vb.add_child(title)

	grid = GridContainer.new()
	grid.columns = 5
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 12)
	vb.add_child(grid)

	info_title = Label.new()
	info_title.add_theme_font_size_override("font_size", 28)
	info_title.add_theme_color_override("font_color", Color(1, 0.85, 0.5))
	vb.add_child(info_title)

	info_desc = Label.new()
	info_desc.add_theme_font_size_override("font_size", 22)
	info_desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info_desc.custom_minimum_size = Vector2(700, 90)
	vb.add_child(info_desc)

	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 14)
	vb.add_child(hb)

	var use_btn := UITheme.menu_button(Localization.tr_key("hud.use"), 24)
	use_btn.custom_minimum_size = Vector2(200, 54)
	use_btn.pressed.connect(_on_use)
	hb.add_child(use_btn)

	var combine_btn := UITheme.menu_button(Localization.tr_key("hud.combine"), 24)
	combine_btn.custom_minimum_size = Vector2(200, 54)
	combine_btn.pressed.connect(_on_combine)
	hb.add_child(combine_btn)

	var close_btn := UITheme.menu_button(Localization.tr_key("hud.close"), 24)
	close_btn.custom_minimum_size = Vector2(200, 54)
	close_btn.pressed.connect(func(): toggle())
	hb.add_child(close_btn)


func toggle() -> void:
	visible = not visible
	if visible:
		selected = -1
		_combine_mode = false
		_combine_first = -1
		_refresh()
	AudioManager.ui_click()


func _refresh() -> void:
	if not visible:
		return
	for c in grid.get_children():
		c.queue_free()
	for i in InventoryManager.MAX_SLOTS:
		var slot := Button.new()
		slot.custom_minimum_size = Vector2(120, 120)
		if i < InventoryManager.items.size():
			var item_id: String = InventoryManager.items[i]
			var def: Dictionary = InventoryManager.ITEMS.get(item_id, {})
			var col: Color = def.get("color", Color(0.5, 0.5, 0.5))
			slot.text = str(def.get("letter", "?"))
			slot.add_theme_font_size_override("font_size", 44)
			slot.add_theme_color_override("font_color", col)
			var sb := UITheme.flat_style(Color(col.r * 0.25, col.g * 0.25, col.b * 0.25, 0.9), col, 2, 14)
			slot.add_theme_stylebox_override("normal", sb)
			slot.pressed.connect(_on_slot.bind(i))
			if i == selected:
				slot.add_theme_stylebox_override("normal", UITheme.flat_style(Color(col.r * 0.5, col.g * 0.5, col.b * 0.5, 0.95), Color(1, 1, 0.6), 3, 14))
			if _combine_mode and i == _combine_first:
				slot.add_theme_stylebox_override("normal", UITheme.flat_style(Color(0.5, 0.45, 0.1, 0.95), Color(1, 0.9, 0.3), 3, 14))
		else:
			slot.text = ""
			slot.disabled = true
			slot.add_theme_stylebox_override("normal", UITheme.flat_style(Color(0.04, 0.04, 0.06, 0.7), Color(0.15, 0.15, 0.18), 1, 14))
		slot.add_theme_stylebox_override("pressed", slot.get_theme_stylebox("normal"))
		slot.add_theme_stylebox_override("hover", slot.get_theme_stylebox("normal"))
		slot.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
		grid.add_child(slot)
	if selected >= 0 and selected < InventoryManager.items.size():
		var item_id: String = InventoryManager.items[selected]
		info_title.text = InventoryManager.get_item_name(item_id)
		info_desc.text = InventoryManager.get_item_desc(item_id)
	else:
		info_title.text = ""
		info_desc.text = ""


func _on_slot(i: int) -> void:
	selected = i
	AudioManager.ui_click()
	_refresh()


func _on_use() -> void:
	if selected < 0 or selected >= InventoryManager.items.size():
		return
	var item_id: String = InventoryManager.items[selected]
	match item_id:
		"flashlight":
			if not Game.flashlight_unlocked:
				Game.flashlight_unlocked = true
				UIManager.show_message(Localization.tr_key("item.flashlight.name"), 2.0)
			else:
				var player := get_tree().get_first_node_in_group("player")
				if player != null and player.has_method("toggle_flashlight"):
					player.toggle_flashlight()
	EventBus.item_used.emit(item_id)


func _on_combine() -> void:
	if selected < 0 or selected >= InventoryManager.items.size():
		return
	if not _combine_mode:
		_combine_mode = true
		_combine_first = selected
		UIManager.show_message(Localization.tr_key("hud.combine"), 1.5)
		_refresh()
		return
	var a: String = InventoryManager.items[_combine_first]
	var b: String = InventoryManager.items[selected]
	var result := InventoryManager.try_combine(a, b)
	_combine_mode = false
	_combine_first = -1
	if result != "":
		UIManager.show_message(Localization.tr_key("hud.combined"), 2.0)
	else:
		UIManager.show_message(Localization.tr_key("hud.cannot_combine"), 2.0)
		AudioManager.play_sfx("puzzle_error", -8.0)
	_refresh()
