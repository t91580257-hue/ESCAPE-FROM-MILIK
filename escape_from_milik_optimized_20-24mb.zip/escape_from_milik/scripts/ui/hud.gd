extends Control
## HUD: prompts, messages, subtitles, objective, crosshair, battery, touch controls,
## plus overlay UIs (pause / inventory / note / keypad / symbols / breaker).

var message_label: Label
var subtitle_label: Label
var objective_label: Label
var prompt_label: Label
var crosshair: ColorRect
var battery_bar: ProgressBar
var touch_controls: Control

var pause_menu: Control
var inventory_ui: Control
var note_reader: Control
var keypad_ui: Control
var symbols_ui: Control
var breaker_ui: Control

var player: CharacterBody3D = null


func _ready() -> void:
	add_to_group("hud")
	theme = UITheme.build()
	_build_hud()
	_build_overlays()
	UIManager.register_hud(self)
	AudioManager.set_ui_root(self)
	var bus := EventBus
	bus.show_message.connect(func(text, dur): UIManager.show_message(text, dur))
	bus.show_subtitle.connect(func(text, dur): UIManager.show_subtitle(text, dur))
	bus.show_note.connect(func(id): note_reader.open_note(id))
	bus.open_keypad.connect(func(_id): keypad_ui.open_keypad())
	bus.open_symbols.connect(func(_id): symbols_ui.open_symbols())
	bus.open_breaker.connect(func(_id): breaker_ui.open_panel())
	bus.item_picked.connect(func(_id): pass)
	EventBus.player_caught.connect(_on_caught)


func _build_hud() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

	crosshair = ColorRect.new()
	crosshair.color = Color(1, 1, 1, 0.55)
	crosshair.size = Vector2(6, 6)
	crosshair.set_anchors_preset(Control.PRESET_CENTER)
	crosshair.offset_left = -3
	crosshair.offset_top = -3
	crosshair.offset_right = 3
	crosshair.offset_bottom = 3
	crosshair.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(crosshair)

	message_label = Label.new()
	message_label.name = "MessageLabel"
	message_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
	message_label.offset_top = 90
	message_label.offset_left = -400
	message_label.offset_right = 400
	message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	message_label.add_theme_font_size_override("font_size", 30)
	message_label.add_theme_color_override("font_color", Color(0.95, 0.9, 0.8))
	message_label.add_theme_constant_override("outline_size", 8)
	message_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	message_label.visible = false
	message_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(message_label)

	subtitle_label = Label.new()
	subtitle_label.name = "SubtitleLabel"
	subtitle_label.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	subtitle_label.offset_top = -170
	subtitle_label.offset_left = -600
	subtitle_label.offset_right = 600
	subtitle_label.offset_bottom = -100
	subtitle_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	subtitle_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle_label.add_theme_font_size_override("font_size", 28)
	subtitle_label.add_theme_color_override("font_color", Color(0.92, 0.92, 0.95))
	subtitle_label.add_theme_constant_override("outline_size", 8)
	subtitle_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.95))
	subtitle_label.visible = false
	subtitle_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(subtitle_label)

	objective_label = Label.new()
	objective_label.name = "ObjectiveLabel"
	objective_label.set_anchors_preset(Control.PRESET_TOP_LEFT)
	objective_label.offset_left = 26
	objective_label.offset_top = 22
	objective_label.offset_right = 700
	objective_label.add_theme_font_size_override("font_size", 22)
	objective_label.add_theme_color_override("font_color", Color(0.85, 0.75, 0.6))
	objective_label.add_theme_constant_override("outline_size", 6)
	objective_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	objective_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(objective_label)

	prompt_label = Label.new()
	prompt_label.name = "PromptLabel"
	prompt_label.set_anchors_preset(Control.PRESET_CENTER)
	prompt_label.offset_top = 60
	prompt_label.offset_left = -350
	prompt_label.offset_right = 350
	prompt_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	prompt_label.add_theme_font_size_override("font_size", 26)
	prompt_label.add_theme_color_override("font_color", Color(1, 0.9, 0.5))
	prompt_label.add_theme_constant_override("outline_size", 8)
	prompt_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	prompt_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(prompt_label)

	battery_bar = ProgressBar.new()
	battery_bar.name = "BatteryBar"
	battery_bar.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	battery_bar.offset_left = 380
	battery_bar.offset_top = -46
	battery_bar.offset_right = 560
	battery_bar.offset_bottom = -24
	battery_bar.min_value = 0
	battery_bar.max_value = 1
	battery_bar.show_percentage = false
	battery_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(battery_bar)

	touch_controls = Control.new()
	touch_controls.set_script(load("res://scripts/player/touch_controls.gd"))
	add_child(touch_controls)
	touch_controls.pause_requested.connect(_on_pause_requested)


func _build_overlays() -> void:
	pause_menu = Control.new()
	pause_menu.set_script(load("res://scripts/ui/pause_menu.gd"))
	add_child(pause_menu)

	inventory_ui = Control.new()
	inventory_ui.set_script(load("res://scripts/ui/inventory_ui.gd"))
	add_child(inventory_ui)

	note_reader = Control.new()
	note_reader.set_script(load("res://scripts/ui/note_reader.gd"))
	add_child(note_reader)

	keypad_ui = Control.new()
	keypad_ui.set_script(load("res://scripts/ui/keypad_ui.gd"))
	add_child(keypad_ui)

	symbols_ui = Control.new()
	symbols_ui.set_script(load("res://scripts/ui/symbols_ui.gd"))
	add_child(symbols_ui)

	breaker_ui = Control.new()
	breaker_ui.set_script(load("res://scripts/ui/breaker_ui.gd"))
	add_child(breaker_ui)


func _process(_delta: float) -> void:
	if player == null:
		player = get_tree().get_first_node_in_group("player")
		if player == null:
			return
	if player.has_signal("interact_target_changed"):
		if not player.interact_target_changed.is_connected(_on_prompt):
			player.interact_target_changed.connect(_on_prompt)
	if Game.flashlight_unlocked:
		battery_bar.visible = true
		battery_bar.value = Game.flashlight_battery
	else:
		battery_bar.visible = false
	if Input.is_action_just_pressed("pause"):
		_on_pause_requested()
	if Input.is_action_just_pressed("inventory"):
		if inventory_ui.has_method("toggle"):
			inventory_ui.toggle()


func _on_prompt(text: String) -> void:
	prompt_label.text = text


func _on_pause_requested() -> void:
	if pause_menu.has_method("open_pause"):
		pause_menu.open_pause()


func _on_caught() -> void:
	pass
