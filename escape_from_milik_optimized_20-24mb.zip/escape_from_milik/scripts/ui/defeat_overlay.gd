extends Control
## Defeat overlay: scary title + retry / main menu buttons.

var overlay: ColorRect = null


func _ready() -> void:
	theme = UITheme.build()
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_build()


func _build() -> void:
	var bg := ColorRect.new()
	bg.color = Color(0.05, 0.0, 0.0, 0.92)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var vb := VBoxContainer.new()
	vb.set_anchors_preset(Control.PRESET_CENTER)
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_theme_constant_override("separation", 24)
	vb.offset_left = -420
	vb.offset_right = 420
	vb.offset_top = -220
	vb.offset_bottom = 220
	add_child(vb)

	var title := UITheme.title_label(Localization.tr_key("lose.title"), 54)
	# creepy pulse
	var tw := create_tween().set_loops()
	tw.tween_property(title, "modulate", Color(1.4, 0.7, 0.7), 0.8)
	tw.tween_property(title, "modulate", Color(0.9, 0.35, 0.35), 0.8)
	vb.add_child(title)

	var hint := Label.new()
	hint.text = Localization.tr_key("lose.hint")
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.add_theme_font_size_override("font_size", 24)
	vb.add_child(hint)

	var stats := Label.new()
	stats.text = "%s %d" % [Localization.tr_key("win.deaths"), Game.times_caught]
	stats.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	stats.add_theme_font_size_override("font_size", 22)
	stats.add_theme_color_override("font_color", Color(0.7, 0.6, 0.6))
	vb.add_child(stats)

	var retry := UITheme.menu_button(Localization.tr_key("menu.retry"), 30)
	retry.pressed.connect(_on_retry)
	vb.add_child(retry)

	var menu := UITheme.menu_button(Localization.tr_key("menu.to_main_menu"), 30)
	menu.pressed.connect(func():
		SceneManager.to_main_menu())
	vb.add_child(menu)


func setup(fade_overlay: ColorRect) -> void:
	overlay = fade_overlay


func _on_retry() -> void:
	var level := get_tree().get_first_node_in_group("level")
	if level != null and level.has_method("respawn_player"):
		level.respawn_player()
	# hide this overlay
	queue_free()
