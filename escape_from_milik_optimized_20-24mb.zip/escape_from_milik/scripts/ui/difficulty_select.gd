extends Control
## Difficulty select: 4 cards, starts a new game.

const DIFFS := ["easy", "normal", "hard", "nightmare"]


func _ready() -> void:
	theme = UITheme.build()
	set_anchors_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = Color(0.02, 0.02, 0.04)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var vb := VBoxContainer.new()
	vb.set_anchors_preset(Control.PRESET_FULL_RECT)
	vb.offset_left = 60
	vb.offset_right = -60
	vb.offset_top = 40
	vb.offset_bottom = -40
	vb.add_theme_constant_override("separation", 20)
	add_child(vb)

	vb.add_child(UITheme.title_label(Localization.tr_key("diff.title"), 48))

	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 20)
	hb.alignment = BoxContainer.ALIGNMENT_CENTER
	hb.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(hb)

	var colors := {
		"easy": Color(0.35, 0.7, 0.45),
		"normal": Color(0.85, 0.75, 0.35),
		"hard": Color(0.9, 0.45, 0.2),
		"nightmare": Color(0.75, 0.1, 0.1),
	}
	for d in DIFFS:
		var card := Button.new()
		card.custom_minimum_size = Vector2(280, 360)
		var col: Color = colors[d]
		card.add_theme_stylebox_override("normal", UITheme.flat_style(Color(col.r * 0.12, col.g * 0.12, col.b * 0.12, 0.95), col, 2, 16))
		card.add_theme_stylebox_override("hover", UITheme.flat_style(Color(col.r * 0.22, col.g * 0.22, col.b * 0.22, 0.98), col, 3, 16))
		card.add_theme_stylebox_override("pressed", card.get_theme_stylebox("hover"))
		card.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
		var vb2 := VBoxContainer.new()
		vb2.set_anchors_preset(Control.PRESET_FULL_RECT)
		vb2.offset_left = 16
		vb2.offset_right = -16
		vb2.offset_top = 24
		vb2.offset_bottom = -16
		vb2.add_theme_constant_override("separation", 14)
		vb2.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var name_l := Label.new()
		name_l.text = Localization.tr_key("diff.%s.name" % d)
		name_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		name_l.add_theme_font_size_override("font_size", 34)
		name_l.add_theme_color_override("font_color", col)
		name_l.mouse_filter = Control.MOUSE_FILTER_IGNORE
		vb2.add_child(name_l)
		var desc := Label.new()
		desc.text = Localization.tr_key("diff.%s.desc" % d)
		desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		desc.add_theme_font_size_override("font_size", 20)
		desc.add_theme_color_override("font_color", Color(0.85, 0.83, 0.8))
		desc.mouse_filter = Control.MOUSE_FILTER_IGNORE
		vb2.add_child(desc)
		card.add_child(vb2)
		card.pressed.connect(_start.bind(d))
		hb.add_child(card)

	var back := UITheme.menu_button(Localization.tr_key("menu.back"), 26)
	back.pressed.connect(func():
		AudioManager.ui_back()
		SceneManager.goto_scene("main_menu"))
	vb.add_child(back)


func _start(diff: String) -> void:
	AudioManager.ui_click()
	Game.start_new_game(diff)
	SceneManager.goto_scene("game")
