extends Control
## Note reader overlay.

var title_label: Label
var text_label: Label


func _ready() -> void:
	theme = UITheme.build()
	set_anchors_preset(Control.PRESET_FULL_RECT)
	visible = false
	_build()


func _build() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.65)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.gui_input.connect(_on_dim_input)
	add_child(dim)

	var panel := PanelContainer.new()
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.custom_minimum_size = Vector2(760, 520)
	add_child(panel)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 20)
	panel.add_child(vb)

	title_label = UITheme.title_label("", 38)
	title_label.add_theme_color_override("font_color", Color(0.9, 0.8, 0.55))
	vb.add_child(title_label)

	text_label = Label.new()
	text_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	text_label.custom_minimum_size = Vector2(700, 300)
	text_label.add_theme_font_size_override("font_size", 26)
	vb.add_child(text_label)

	var close_btn := UITheme.menu_button(Localization.tr_key("hud.close"), 26)
	close_btn.pressed.connect(func(): visible = false)
	vb.add_child(close_btn)


func _on_dim_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch and event.pressed:
		visible = false


func open_note(note_id: String) -> void:
	title_label.text = Localization.tr_key("note." + note_id + ".title")
	text_label.text = Localization.tr_key("note." + note_id + ".text")
	visible = true
	AudioManager.play_sfx("paper", -6.0)


func _unhandled_input(event: InputEvent) -> void:
	if visible and event.is_action_pressed("ui_cancel"):
		visible = false
