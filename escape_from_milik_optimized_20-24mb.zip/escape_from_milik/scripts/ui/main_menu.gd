extends Node3D
## Main menu: 3D scene (old house + evil Milik) + animated UI.

@onready var milik_root: Node3D = $EvilMilik
@onready var camera: Camera3D = $MenuCamera
@onready var lantern_light: OmniLight3D = $HouseFacade/Lantern/ OmniLight3D if has_node("HouseFacade/Lantern/OmniLight3D") else null

var _time := 0.0
var _base_milik_pos: Vector3
var _next_approach := 6.0
var _approaching := false
var ui_layer: CanvasLayer


func _ready() -> void:
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	get_tree().paused = false
	_base_milik_pos = milik_root.global_position if milik_root != null else Vector3.ZERO
	_build_ui()
	AudioManager.play_music("menu", 2.0, -8.0)
	AudioManager.play_ambient_3d("wind_loop", self, global_position + Vector3(0, 2, 8), -6.0)
	_apply_quality()


func _apply_quality() -> void:
	var env := get_node_or_null("WorldEnvironment") as WorldEnvironment
	if env == null or env.environment == null:
		return
	env.environment.glow_enabled = SettingsManager.bloom
	env.environment.fog_enabled = SettingsManager.fog_effects
	camera.far = 90.0


func _build_ui() -> void:
	ui_layer = CanvasLayer.new()
	add_child(ui_layer)
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.theme = UITheme.build()
	ui_layer.add_child(root)

	# left column of buttons, title on top
	var title := UITheme.title_label(Localization.tr_key("game.title"), 72)
	title.set_anchors_preset(Control.PRESET_CENTER_TOP)
	title.offset_top = 70
	title.offset_left = -500
	title.offset_right = 500
	root.add_child(title)

	var subtitle := Label.new()
	subtitle.text = "ESCAPE FROM MILIK"
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_font_size_override("font_size", 22)
	subtitle.add_theme_color_override("font_color", Color(0.55, 0.5, 0.48))
	subtitle.set_anchors_preset(Control.PRESET_CENTER_TOP)
	subtitle.offset_top = 160
	subtitle.offset_left = -500
	subtitle.offset_right = 500
	root.add_child(subtitle)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 16)
	vb.set_anchors_preset(Control.PRESET_CENTER_LEFT)
	vb.offset_left = 110
	vb.offset_top = -190
	root.add_child(vb)

	_add_btn(vb, Localization.tr_key("menu.new_game"), func():
		SceneManager.goto_scene("difficulty"))
	var cont := _add_btn(vb, Localization.tr_key("menu.continue"), func():
		_load_continue())
	if not SaveManager.has_save():
		cont.disabled = true
		cont.text = Localization.tr_key("menu.continue_disabled")
	_add_btn(vb, Localization.tr_key("menu.difficulty"), func():
		SceneManager.goto_scene("difficulty"))
	_add_btn(vb, Localization.tr_key("menu.settings"), func():
		SceneManager.goto_scene("settings"))
	_add_btn(vb, Localization.tr_key("menu.about"), func():
		SceneManager.goto_scene("about"))
	_add_btn(vb, Localization.tr_key("menu.exit"), func():
		get_tree().quit())

	# fade-in animation
	root.modulate.a = 0.0
	var tw := create_tween()
	tw.tween_property(root, "modulate:a", 1.0, 1.2)
	title.pivot_offset = title.size * 0.5
	var tw2 := create_tween().set_loops()
	tw2.tween_property(title, "modulate", Color(1.2, 0.75, 0.7), 1.6).set_trans(Tween.TRANS_SINE)
	tw2.tween_property(title, "modulate", Color(0.85, 0.35, 0.3), 1.6).set_trans(Tween.TRANS_SINE)


func _add_btn(parent: Control, text: String, cb: Callable) -> Button:
	var b := UITheme.menu_button(text, 30)
	b.alignment = HORIZONTAL_ALIGNMENT_CENTER
	b.pressed.connect(cb)
	parent.add_child(b)
	return b


func _load_continue() -> void:
	var data := SaveManager.read_save()
	if data.is_empty():
		return
	Game.load_state(data)
	Game.pending_load = true
	Game.pending_load_payload = data
	SceneManager.goto_scene("game")


func _process(delta: float) -> void:
	_time += delta
	# cinematic camera sway
	if camera != null:
		camera.position.x = sin(_time * 0.22) * 0.35
		camera.rotation.y = -0.18 + sin(_time * 0.13) * 0.02
		camera.rotation.x = 0.05 + sin(_time * 0.17) * 0.015
	# evil milik idle: breathe + slow sway + occasional approach
	if milik_root != null:
		var breath := 1.0 + sin(_time * 1.3) * 0.015
		milik_root.scale = Vector3.ONE * 0.24 * breath
		milik_root.rotation_degrees.z = sin(_time * 0.8) * 1.5
		_next_approach -= delta
		if _next_approach <= 0.0 and not _approaching:
			_approaching = true
			_next_approach = randf_range(9.0, 16.0)
			var tw := create_tween()
			var target := _base_milik_pos + Vector3(0.6, 0, 2.2)
			tw.tween_property(milik_root, "global_position", target, 1.6).set_trans(Tween.TRANS_SINE)
			tw.tween_callback(func():
				AudioManager.play_monster_3d("monster_giggle", self, milik_root.global_position, -2.0))
			tw.tween_interval(1.4)
			tw.tween_property(milik_root, "global_position", _base_milik_pos, 2.2)
			tw.tween_callback(func(): _approaching = false)
	# lantern flicker
	var lamp := get_node_or_null("HouseFacade/LanternLight") as OmniLight3D
	if lamp != null:
		lamp.light_energy = 1.1 + sin(_time * 7.3) * randf_range(0.05, 0.22)
