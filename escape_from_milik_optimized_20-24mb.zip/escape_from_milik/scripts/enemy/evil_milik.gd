extends Node3D
## EvilMilik visuals: GLB model, eye glow, procedural creepy motion, attack anim.

@export var model_path: String = "res://models/characters/milik_evil.glb"
@export var model_scale: float = 0.24
@export var yaw_flip: bool = false  # set true if model faces +Z after Z-up->Y-up remap

var _model_root: Node3D
var _anim: AnimationPlayer = null
var _walking := false
var _speed := 0.0
var _time := 0.0
var _attack_time := -10.0
var _base_y_rot := 0.0


func _ready() -> void:
	_instantiate_model()
	_setup_eye_glow()
	_setup_ambient_voices()


func _instantiate_model() -> void:
	if not ResourceLoader.exists(model_path):
		push_warning("EvilMilik: model missing " + model_path)
		return
	var scene: PackedScene = load(model_path)
	_model_root = Node3D.new()
	add_child(_model_root)
	_model_root.rotation_degrees = Vector3(-90, 0, 0)
	if yaw_flip:
		_model_root.rotation_degrees.y = 180.0
	_model_root.scale = Vector3.ONE * model_scale
	var inst := scene.instantiate()
	_model_root.add_child(inst)
	_anim = inst.find_child("AnimationPlayer", true, false)
	if _anim != null:
		var walk_name := _find_anim(["Walk_Loop", "Walk"])
		var shake_name := _find_anim(["Angry_Shake_Loop", "Angry_Shake"])
		if walk_name != "":
			var a := _anim.get_animation(walk_name)
			a.loop_mode = Animation.LOOP_LINEAR
			_anim.play(walk_name)
			_anim.speed_scale = 0.0
		if shake_name != "":
			_anim.get_animation(shake_name).loop_mode = Animation.LOOP_LINEAR


func _setup_eye_glow() -> void:
	if _model_root == null:
		return
	var meshes: Array[Node] = []
	_collect_meshes(_model_root, meshes)
	for node in meshes:
		var mi := node as MeshInstance3D
		if mi == null or mi.mesh == null:
			continue
		for i in range(mi.mesh.get_surface_count()):
			var mat: Material = mi.get_active_material(i)
			if mat is StandardMaterial3D and (mat as StandardMaterial3D).resource_name.begins_with("eyes_glow"):
				var m: StandardMaterial3D = (mat as StandardMaterial3D).duplicate()
				m.emission_enabled = true
				m.emission = Color(1.0, 0.12, 0.05)
				m.emission_energy_multiplier = 2.4
				mi.set_surface_override_material(i, m)


func _collect_meshes(node: Node, out: Array[Node]) -> void:
	for c in node.get_children():
		if c is MeshInstance3D:
			out.append(c)
		_collect_meshes(c, out)


func _setup_ambient_voices() -> void:
	# breathing handled globally by level; occasional giggle here
	var t := Timer.new()
	t.wait_time = randf_range(9.0, 16.0)
	t.one_shot = false
	t.timeout.connect(func():
		if Game.monster_active and randf() < 0.5:
			AudioManager.play_monster_3d("monster_giggle", get_parent(), global_position, -10.0))
	add_child(t)
	t.start()


func set_walking(walking: bool, speed: float = 0.0) -> void:
	_walking = walking
	_speed = speed


func play_attack() -> void:
	_attack_time = _time


func _process(delta: float) -> void:
	_time += delta
	if _anim != null:
		var target_scale := 0.0
		if _walking:
			target_scale = clampf(0.6 + _speed * 0.5, 0.7, 2.2)
		_anim.speed_scale = lerpf(_anim.speed_scale, target_scale, 6.0 * delta)
	# creep factor: lean forward while chasing, rock body while walking
	var chase := Game.monster_active
	var lean := 0.10 if chase else 0.0
	var rock := sin(_time * 3.0) * (0.045 if _walking else 0.012)
	_model_root.rotation_degrees.z = rock
	_model_root.rotation_degrees.x = lean
	# breathing
	var breath := 1.0 + sin(_time * 1.7) * 0.012
	_model_root.scale = Vector3.ONE * model_scale * breath
	# attack lunge punch
	var since := _time - _attack_time
	if since < 0.5:
		var punch := sin(since / 0.5 * PI)
		_model_root.position.z = -0.25 * punch
		_model_root.scale = Vector3.ONE * model_scale * (1.0 + 0.25 * punch)
	else:
		_model_root.position.z = 0.0
	# eye pulse
	_time_eye_pulse(delta)


func _time_eye_pulse(_delta: float) -> void:
	pass


func _find_anim(names: Array) -> String:
	if _anim == null:
		return ""
	for n in names:
		if _anim.has_animation(n):
			return n
	return ""


func play_shake() -> void:
	var n := _find_anim(["Angry_Shake_Loop", "Angry_Shake"])
	if _anim != null and n != "":
		_anim.play(n)
