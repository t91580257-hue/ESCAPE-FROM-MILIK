extends CharacterBody3D
## EnemyAI: Evil Milik FSM with waypoint-graph navigation (AStar3D).
## States: PATROL, INVESTIGATE, SEARCH, CHASE, LOST_TARGET, RETURN, ATTACK

enum State { PATROL, INVESTIGATE, SEARCH, CHASE, LOST_TARGET, RETURN, ATTACK }

signal state_changed(new_state: int)

const VISION_CHECK_INTERVAL := 0.18
const GRAVITY := 14.0

@export var patrol_points_path: NodePath
@export var player_path: NodePath

var state: int = State.PATROL
var player: CharacterBody3D = null
var visual: Node3D = null
var level: Node = null

var patrol_points: Array[Vector3] = []
var _patrol_index := 0
var _vision_timer := 0.0
var _investigate_point := Vector3.ZERO
var _last_known_player := Vector3.ZERO
var _path: Array[Vector3] = []
var _path_index := 0
var _repath_timer := 0.0
var _search_timer := 0.0
var _lost_timer := 0.0
var _step_accum := 0.0
var _growl_timer := 0.0
var _state_time := 0.0
var _hide_spots: Array[Node] = []
var _hide_check_index := 0
var _catch_cooldown := 0.0
var _attack_done := false


func _ready() -> void:
	add_to_group("monster")
	visual = get_node_or_null("Visual")
	if player_path != null:
		player = get_node_or_null(player_path) as CharacterBody3D
	var pp := get_node_or_null(patrol_points_path)
	if pp != null:
		for c in pp.get_children():
			if c is Node3D:
				patrol_points.append(c.global_position)
	if patrol_points.is_empty():
		patrol_points.append(global_position)
	EventBus.noise_emitted.connect(_on_noise)
	_collect_hide_spots()


func _collect_hide_spots() -> void:
	_hide_spots.clear()
	var tree := get_tree()
	if tree != null:
		for n in tree.get_nodes_in_group("hide_spots"):
			_hide_spots.append(n)


func set_level(l: Node) -> void:
	level = l


func _physics_process(delta: float) -> void:
	if player == null:
		player = get_tree().get_first_node_in_group("player")
		if player == null:
			return
	if not Game.monster_active:
		velocity.x = 0
		velocity.z = 0
		if not is_on_floor():
			velocity.y -= GRAVITY * delta
		move_and_slide()
		if visual != null and visual.has_method("set_walking"):
			visual.set_walking(false)
		return
	_state_time += delta
	_catch_cooldown = maxf(0.0, _catch_cooldown - delta)
	_vision_timer -= delta
	if _vision_timer <= 0.0:
		_vision_timer = VISION_CHECK_INTERVAL
		_vision_update()
	match state:
		State.PATROL:
			_do_patrol(delta)
		State.INVESTIGATE:
			_do_investigate(delta)
		State.SEARCH:
			_do_search(delta)
		State.CHASE:
			_do_chase(delta)
		State.LOST_TARGET:
			_do_lost(delta)
		State.RETURN:
			_do_return(delta)
		State.ATTACK:
			_do_attack(delta)
	_process_locomotion(delta)


func _set_state(s: int) -> void:
	if state == s:
		return
	state = s
	_state_time = 0.0
	state_changed.emit(s)
	EventBus.monster_state_changed.emit(State.keys()[s])
	if s == State.INVESTIGATE:
		AudioManager.play_monster_3d("monster_giggle", get_parent(), global_position, -2.0)
	elif s == State.CHASE:
		AudioManager.play_monster_3d("monster_growl_" + str(randi_range(1, 3)), get_parent(), global_position, 2.0)
	elif s == State.ATTACK:
		_attack_done = false
		AudioManager.play_monster_3d("monster_growl_2", get_parent(), global_position, 4.0)


# ---------- senses ----------
func _vision_update() -> void:
	if player == null:
		return
	if player.is_hidden():
		return
	var to_player: Vector3 = player.global_position - global_position
	var dist := to_player.length()
	var base_range: float = DifficultyManager.param("vision_range")
	var range_mult := 1.0
	if not Game.power_on:
		range_mult = 0.7
	var fl: SpotLight3D = player.get_node_or_null("Head/Camera3D/FlashlightRig/SpotLight3D")
	if fl != null and fl.visible:
		range_mult *= 1.35
	var eff_range := base_range * range_mult * (1.0 + 0.08 * Game.aggression_stage)
	if dist > eff_range:
		return
	var fov_deg: float = DifficultyManager.param("vision_fov_deg")
	var forward := -global_transform.basis.z
	var dir := to_player.normalized()
	if rad_to_deg(forward.angle_to(dir)) > fov_deg * 0.5:
		return
	if not _quick_los():
		return
	_last_known_player = player.global_position
	if state != State.ATTACK:
		if dist <= float(DifficultyManager.param("attack_range")) * 1.4:
			_set_state(State.ATTACK)
		else:
			_set_state(State.CHASE)


func _on_noise(pos: Vector3, loudness: float, kind: String) -> void:
	if not Game.monster_active:
		return
	if state == State.CHASE or state == State.ATTACK:
		return
	if loudness <= 0.0:
		return
	var hear_radius: float = 22.0 * loudness * float(DifficultyManager.param("hearing_multiplier"))
	var dist := global_position.distance_to(pos)
	if dist <= hear_radius:
		_investigate_point = pos
		_last_known_player = pos
		_set_state(State.INVESTIGATE)


# ---------- states ----------
func _do_patrol(delta: float) -> void:
	if patrol_points.is_empty():
		return
	var target := patrol_points[_patrol_index]
	_steer_along_path(target, delta, float(DifficultyManager.param("monster_speed_walk")))
	if global_position.distance_to(target) < 1.2:
		_patrol_index = (_patrol_index + 1) % patrol_points.size()
		_path.clear()
	_growl_tick(delta)


func _do_investigate(delta: float) -> void:
	_steer_along_path(_investigate_point, delta, float(DifficultyManager.param("monster_speed_walk")) * 1.15)
	if global_position.distance_to(_investigate_point) < 1.3 or _state_time > 12.0:
		_begin_search()


func _do_chase(delta: float) -> void:
	var target := _last_known_player
	if player != null and not player.is_hidden() and _quick_los():
		target = player.global_position
		_last_known_player = target
		_lost_timer = 0.0
	else:
		_lost_timer += delta
		if _lost_timer > float(DifficultyManager.param("chase_give_up_time")):
			_set_state(State.LOST_TARGET)
			return
	_steer_along_path(target, delta, float(DifficultyManager.param("monster_speed_chase")), true)
	if player != null and not player.is_hidden():
		var dist := global_position.distance_to(player.global_position)
		if dist <= float(DifficultyManager.param("attack_range")) and _catch_cooldown <= 0.0:
			_set_state(State.ATTACK)


func _do_lost(delta: float) -> void:
	velocity.x = 0
	velocity.z = 0
	# look around briefly, then search
	rotation.y += delta * 2.2
	if _state_time > 1.4:
		_begin_search()


func _do_search(delta: float) -> void:
	_search_timer -= delta
	if _search_timer <= 0.0:
		_set_state(State.RETURN)
		return
	if _path_index < _search_points_left():
		pass
	if _current_search_points.is_empty():
		_set_state(State.RETURN)
		return
	var target := _current_search_points[_search_index]
	_steer_along_path(target, delta, float(DifficultyManager.param("monster_speed_walk")) * 1.1)
	if global_position.distance_to(target) < 1.2:
		_search_index += 1
		if _search_index >= _current_search_points.size():
			_set_state(State.RETURN)
	_growl_tick(delta)


var _current_search_points: Array[Vector3] = []
var _search_index := 0


func _search_points_left() -> int:
	return max(0, _current_search_points.size() - _search_index)


func _do_return(delta: float) -> void:
	if patrol_points.is_empty():
		_set_state(State.PATROL)
		return
	var nearest := 0
	var best := 1e9
	for i in patrol_points.size():
		var d := global_position.distance_to(patrol_points[i])
		if d < best:
			best = d
			nearest = i
	_steer_along_path(patrol_points[nearest], delta, float(DifficultyManager.param("monster_speed_walk")))
	if best < 1.4:
		_patrol_index = (nearest + 1) % patrol_points.size()
		_set_state(State.PATROL)


func _do_attack(delta: float) -> void:
	velocity.x = 0
	velocity.z = 0
	if visual != null and visual.has_method("play_attack"):
		visual.play_attack()
	if not _attack_done and _state_time > 0.45 and player != null:
		var dist := global_position.distance_to(player.global_position)
		if dist <= float(DifficultyManager.param("attack_range")) * 1.6 and not player.is_hidden():
			_attack_done = true
			if level != null and level.has_method("on_player_caught"):
				level.on_player_caught()
			else:
				EventBus.player_caught.emit()
		# after the lunge, back off to patrol if missed
		if _state_time > 1.1 and not _attack_done:
			_attack_done = true
			_catch_cooldown = 1.5
			_set_state(State.CHASE)


func _begin_search() -> void:
	var points: Array[Vector3] = []
	var count := int(DifficultyManager.param("search_points"))
	for i in count:
		var p := _random_search_point(_last_known_player, 6.0)
		if p != Vector3.INF:
			points.append(p)
	# occasionally check a hiding spot
	var chance := float(DifficultyManager.param("hide_check_chance"))
	if not _hide_spots.is_empty() and randf() < chance:
		_hide_check_index = (_hide_check_index + 1) % _hide_spots.size()
		var spot: Node3D = _hide_spots[_hide_check_index] as Node3D
		if spot != null:
			points.append(spot.global_position + spot.global_transform.basis.z * 0.9)
	if points.is_empty():
		_set_state(State.RETURN)
		return
	_current_search_points = points
	_search_index = 0
	_search_timer = float(DifficultyManager.param("search_time"))
	_path.clear()
	_set_state(State.SEARCH)


func _random_search_point(center: Vector3, radius: float) -> Vector3:
	var wp := _waypoints()
	for attempt in 8:
		var offset := Vector3(randf_range(-radius, radius), 0, randf_range(-radius, radius))
		var candidate := center + offset
		var best: Vector3 = Vector3.INF
		var best_d := 1e9
		for w in wp:
			var d: float = w.distance_to(candidate)
			if d < best_d:
				best_d = d
				best = w
		if best != Vector3.INF and best_d < 2.5 and best.distance_to(global_position) > 1.5:
			return best
	return Vector3.INF


# ---------- navigation (waypoint graph via AStar3D) ----------
var _astar: AStar3D = null
var _wp_points: Array[Vector3] = []


func setup_navigation(astar: AStar3D, points: Array[Vector3]) -> void:
	_astar = astar
	_wp_points = points


func _waypoints() -> Array[Vector3]:
	if _astar != null:
		return _wp_points
	return patrol_points


func _nav_path(from: Vector3, to: Vector3) -> Array[Vector3]:
	var result: Array[Vector3] = []
	if _astar == null:
		result.append(to)
		return result
	var id_from := _closest_wp_id(from)
	var id_to := _closest_wp_id(to)
	if id_from < 0 or id_to < 0:
		result.append(to)
		return result
	var ids := _astar.get_id_path(id_from, id_to)
	if ids.is_empty():
		# fallback: straight line if same room & LOS
		result.append(to)
		return result
	for id in ids:
		result.append(_astar.get_point_position(id))
	result.append(to)
	return result


func _closest_wp_id(pos: Vector3) -> int:
	if _astar == null:
		return -1
	var best_id := -1
	var best_d := 1e9
	for id in _astar.get_point_ids():
		var d: float = _astar.get_point_position(id).distance_to(pos)
		if d < best_d and _astar.is_point_disabled(id) == false:
			best_d = d
			best_id = id
	return best_id


func _steer_along_path(target: Vector3, delta: float, speed: float, chase_direct_ok: bool = false) -> void:
	_repath_timer -= delta
	if _repath_timer <= 0.0 or _path.is_empty() or _path_index >= _path.size():
		_repath_timer = 0.5
		_path = _nav_path(global_position, target)
		_path_index = 0
	var direct := false
	if chase_direct_ok and _quick_los():
		direct = true
	var steer_target := target
	if not direct:
		# find first path point that is not behind us/close
		while _path_index < _path.size() - 1 and global_position.distance_to(_path[_path_index]) < 0.9:
			_path_index += 1
		steer_target = _path[_path_index] if _path_index < _path.size() else target
	var dir := steer_target - global_position
	dir.y = 0
	if dir.length() > 0.06:
		dir = dir.normalized()
		velocity.x = dir.x * speed
		velocity.z = dir.z * speed
		var target_angle := atan2(-dir.x, -dir.z)
		rotation.y = lerp_angle(rotation.y, target_angle, 7.0 * delta)
	else:
		velocity.x = 0
		velocity.z = 0


func _process_locomotion(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	else:
		velocity.y = maxf(velocity.y - GRAVITY * delta, 0.0)
	move_and_slide()
	var speed2d := Vector2(velocity.x, velocity.z).length()
	if visual != null and visual.has_method("set_walking"):
		visual.set_walking(speed2d > 0.3, speed2d)
	if speed2d > 0.4:
		_step_accum += speed2d * delta
		if _step_accum > 1.05:
			_step_accum = 0.0
			AudioManager.play_monster_3d("monster_step_" + str(randi_range(1, 3)), get_parent(), global_position, -3.0)


func _growl_tick(delta: float) -> void:
	_growl_timer -= delta
	if _growl_timer <= 0.0:
		_growl_timer = randf_range(7.0, 14.0)
		AudioManager.play_monster_3d("monster_growl_" + str(randi_range(1, 3)), get_parent(), global_position, -6.0)


func _quick_los() -> bool:
	if player == null or player.is_hidden():
		return false
	var space := get_world_3d().direct_space_state
	var query := PhysicsRayQueryParameters3D.create(global_position + Vector3.UP * 0.5, player.global_position + Vector3.UP * 1.2)
	query.exclude = [self]
	var hit := space.intersect_ray(query)
	return hit.is_empty() or hit.get("collider") == player


func reset_to(pos: Vector3) -> void:
	global_position = pos
	state = State.PATROL
	_patrol_index = 0
	_path.clear()
	_last_known_player = pos
