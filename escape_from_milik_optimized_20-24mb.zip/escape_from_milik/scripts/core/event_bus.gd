extends Node
## EventBus: global signal hub for cross-system communication.

# Player / world
signal noise_emitted(position: Vector3, loudness: float, kind: String)
signal door_toggled(door_id: String, opened: bool)
signal player_hidden_changed(hidden: bool)
signal flashlight_toggled(on: bool)

# Items / inventory
signal item_picked(item_id: String)
signal item_used(item_id: String)
signal item_combined(result_id: String)
signal inventory_changed

# Puzzles
signal puzzle_solved(puzzle_id: String)
signal power_changed(on: bool)

# Story
signal story_flag_set(flag: String)
signal show_message(text: String, duration: float)
signal show_subtitle(text: String, duration: float)
signal show_note(note_id: String)
signal open_keypad(lock_id: String)
signal keypad_entered(lock_id: String, code: String)
signal open_symbols(cabinet_id: String)
signal symbols_entered(cabinet_id: String, sequence: Array)
signal open_breaker(panel_id: String)
signal breaker_flipped(panel_id: String, lever_index: int)
signal breaker_solved(panel_id: String)

# Enemy
signal monster_state_changed(state: String)
signal player_caught

# Game lifecycle
signal game_started(difficulty: String)
signal game_won(stats: Dictionary)
signal game_lost
signal autosaved(slot: String)
signal checkpoint_reached(id: String)
