extends Node
## SaveManager: world-state saves (JSON) + autosave slots + continue support.

const SAVE_DIR := "user://saves"
const MAIN_SLOT := "main"
const SETTINGS_HINT := "user://settings.cfg"

var last_save_meta: Dictionary = {}


func _ready() -> void:
        DirAccess.make_dir_recursive_absolute(SAVE_DIR)


func _slot_path(slot: String) -> String:
        return SAVE_DIR + "/" + slot + ".json"


func has_save(slot: String = MAIN_SLOT) -> bool:
        return FileAccess.file_exists(_slot_path(slot))


func write_save(data: Dictionary, slot: String = MAIN_SLOT) -> void:
        data["version"] = 1
        data["timestamp"] = Time.get_datetime_string_from_system()
        data["unix_time"] = Time.get_unix_time_from_system()
        var f := FileAccess.open(_slot_path(slot), FileAccess.WRITE)
        if f == null:
                push_error("SaveManager: cannot write save")
                return
        f.store_string(JSON.stringify(data, "\t"))
        f.close()
        last_save_meta = {"slot": slot, "time": data["timestamp"]}
        EventBus.autosaved.emit(slot)


func read_save(slot: String = MAIN_SLOT) -> Dictionary:
        if not has_save(slot):
                return {}
        var f := FileAccess.open(_slot_path(slot), FileAccess.READ)
        if f == null:
                return {}
        var parsed: Variant = JSON.parse_string(f.get_as_text())
        f.close()
        if parsed is Dictionary:
                return parsed
        return {}


func delete_save(slot: String = MAIN_SLOT) -> void:
        if has_save(slot):
                DirAccess.remove_absolute(ProjectSettings.globalize_path(_slot_path(slot)))
                last_save_meta = {}


func get_last_save_time() -> String:
        var d := read_save(MAIN_SLOT)
        return d.get("timestamp", "")
