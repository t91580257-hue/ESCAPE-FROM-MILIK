extends Node
## SceneManager: async scene transitions through the loading screen.

const SCENES := {
	"main_menu": "res://scenes/main_menu.tscn",
	"game": "res://scenes/game.tscn",
	"settings": "res://scenes/ui/settings_menu.tscn",
	"about": "res://scenes/ui/about_menu.tscn",
	"difficulty": "res://scenes/ui/difficulty_select.tscn",
}

var _loading := false


func goto_scene(key: String, loading_tips: bool = true) -> void:
	if _loading:
		return
	var path: String = SCENES.get(key, "")
	if path == "" or not ResourceLoader.exists(path):
		push_error("SceneManager: unknown scene " + key)
		return
	_loading = true
	get_tree().paused = false
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	if key != "main_menu":
		await _show_loading(path, loading_tips)
	else:
		get_tree().change_scene_to_file(path)
	_loading = false


func _show_loading(path: String, tips: bool) -> void:
	var tree := get_tree()
	var old_scene := tree.current_scene
	# instancing loading screen directly (it lives outside the scene switch)
	var loading_scene: PackedScene = load("res://scenes/ui/loading_screen.tscn")
	var loading := loading_scene.instantiate()
	# keep old scene visible until loading screen shows
	tree.root.add_child(loading)
	loading.start_fake_progress()
	await tree.process_frame
	await tree.process_frame
	# load new scene resource in chunks
	var pak: PackedScene = load(path)
	# give the loading screen at least ~0.8s
	await tree.create_timer(0.8).timeout
	if old_scene != null:
		old_scene.queue_free()
	var inst := pak.instantiate()
	tree.root.add_child(inst)
	tree.current_scene = inst
	loading.finish_and_fade()
	await tree.create_timer(0.9).timeout
	loading.queue_free()


func restart_game() -> void:
	get_tree().paused = false
	goto_scene("game")


func to_main_menu() -> void:
	get_tree().paused = false
	Game.is_playing = false
	goto_scene("main_menu")
