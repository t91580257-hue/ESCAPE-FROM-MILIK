extends Node
## AudioManager: music crossfade, 3D SFX spawning, UI sounds, bus routing.

const MUSIC := {
	"menu": "res://audio/music_menu.ogg",
	"ambient": "res://audio/music_ambient.ogg",
	"chase": "res://audio/music_chase.ogg",
	"yard": "res://audio/music_yard.ogg",
	"victory": "res://audio/music_victory.ogg",
}

const SFX := {
	"ui_click": "res://audio/ui_click.ogg",
	"ui_hover": "res://audio/ui_hover.ogg",
	"ui_back": "res://audio/ui_back.ogg",
	"pickup": "res://audio/pickup.ogg",
	"paper": "res://audio/paper.ogg",
	"door_open": "res://audio/door_open.ogg",
	"door_close": "res://audio/door_close.ogg",
	"door_locked": "res://audio/door_locked.ogg",
	"puzzle_click": "res://audio/puzzle_click.ogg",
	"puzzle_error": "res://audio/puzzle_error.ogg",
	"puzzle_success": "res://audio/puzzle_success.ogg",
	"switch_flip": "res://audio/switch_flip.ogg",
	"generator_start": "res://audio/generator_start.ogg",
	"generator_loop": "res://audio/generator_loop.ogg",
	"cage_open": "res://audio/cage_open.ogg",
	"scare_stinger": "res://audio/scare_stinger.ogg",
	"catch_scream": "res://audio/catch_scream.ogg",
	"victory_stinger": "res://audio/victory_stinger.ogg",
	"lose_stinger": "res://audio/lose_stinger.ogg",
	"hide_in": "res://audio/hide_in.ogg",
	"hide_out": "res://audio/hide_out.ogg",
	"flashlight_click": "res://audio/flashlight_click.ogg",
	"whisper_1": "res://audio/whisper_1.ogg",
	"whisper_2": "res://audio/whisper_2.ogg",
}

const MONSTER_SFX := {
	"monster_step_1": "res://audio/monster_step_1.ogg",
	"monster_step_2": "res://audio/monster_step_2.ogg",
	"monster_step_3": "res://audio/monster_step_3.ogg",
	"monster_growl_1": "res://audio/monster_growl_1.ogg",
	"monster_growl_2": "res://audio/monster_growl_2.ogg",
	"monster_growl_3": "res://audio/monster_growl_3.ogg",
	"monster_giggle": "res://audio/monster_giggle.ogg",
	"monster_breath": "res://audio/monster_breath.ogg",
	"heartbeat_loop": "res://audio/heartbeat_loop.ogg",
}

const AMBIENCE := {
	"wind_loop": "res://audio/wind_loop.ogg",
	"room_tone": "res://audio/room_tone.ogg",
	"basement_hum": "res://audio/basement_hum.ogg",
	"clock_tick": "res://audio/clock_tick.ogg",
	"attic_scratch": "res://audio/attic_scratch.ogg",
}

const STEPS := {
	"wood": ["res://audio/step_wood_1.ogg", "res://audio/step_wood_2.ogg", "res://audio/step_wood_3.ogg", "res://audio/step_wood_4.ogg"],
	"grass": ["res://audio/step_grass_1.ogg", "res://audio/step_grass_2.ogg", "res://audio/step_grass_3.ogg"],
	"concrete": ["res://audio/step_concrete_1.ogg", "res://audio/step_concrete_2.ogg", "res://audio/step_concrete_3.ogg"],
}

var _streams: Dictionary = {}
var _music_player: AudioStreamPlayer
var _music_next: AudioStreamPlayer
var _current_music: String = ""
var _ui_root: Node = null


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_setup_reverb()
	_music_player = AudioStreamPlayer.new()
	_music_player.bus = "Music"
	add_child(_music_player)
	_music_next = AudioStreamPlayer.new()
	_music_next.bus = "Music"
	add_child(_music_next)


func _setup_reverb() -> void:
	# subtle world reverb on the ambience bus for interior spaces
	var idx := AudioServer.get_bus_index("Ambience")
	if idx >= 0:
		var fx := AudioEffectReverb.new()
		fx.room_size = 0.8
		fx.damping = 0.6
		fx.wet = 0.25
		fx.dry = 0.9
		AudioServer.add_bus_effect(idx, fx)


func _stream(path: String) -> AudioStream:
	if not _streams.has(path):
		if not ResourceLoader.exists(path):
			push_warning("AudioManager: missing stream " + path)
			return null
		_streams[path] = load(path)
	return _streams[path]


func play_music(name_key: String, fade: float = 1.5, volume_db: float = -6.0) -> void:
	var path: String = MUSIC.get(name_key, "")
	if path == "" or _current_music == name_key:
		return
	var stream := _stream(path)
	if stream == null:
		return
	_current_music = name_key
	var tween := create_tween()
	if _music_player.playing:
		tween.parallel().tween_property(_music_player, "volume_db", -40.0, fade * 0.5)
	tween.tween_callback(func():
		_music_player.stream = stream
		_music_player.volume_db = -40.0
		_music_player.play())
	tween.tween_property(_music_player, "volume_db", volume_db, fade)


func stop_music(fade: float = 1.0) -> void:
	_current_music = ""
	if _music_player.playing:
		var tw := create_tween()
		tw.tween_property(_music_player, "volume_db", -40.0, fade)
		tw.tween_callback(_music_player.stop)


func play_sfx(name_key: String, volume_db: float = 0.0) -> void:
	var stream := _stream(SFX.get(name_key, ""))
	if stream == null:
		return
	var p := AudioStreamPlayer.new()
	p.stream = stream
	p.bus = "SFX"
	p.volume_db = volume_db
	add_child(p)
	p.finished.connect(p.queue_free)
	p.play()


func play_monster(name_key: String, volume_db: float = 0.0) -> void:
	var stream := _stream(MONSTER_SFX.get(name_key, ""))
	if stream == null:
		return
	var p := AudioStreamPlayer.new()
	p.stream = stream
	p.bus = "Monster"
	p.volume_db = volume_db
	add_child(p)
	p.finished.connect(p.queue_free)
	p.play()


func play_sfx_3d(name_key: String, parent: Node, position: Vector3, bus: String = "SFX", volume_db: float = 0.0, max_dist: float = 24.0) -> AudioStreamPlayer3D:
	var stream := _stream(SFX.get(name_key, ""))
	if stream == null:
		return null
	return _spawn_3d(stream, parent, position, bus, volume_db, max_dist)


func play_monster_3d(name_key: String, parent: Node, position: Vector3, volume_db: float = 0.0, max_dist: float = 30.0) -> AudioStreamPlayer3D:
	var stream := _stream(MONSTER_SFX.get(name_key, ""))
	if stream == null:
		return null
	return _spawn_3d(stream, parent, position, "Monster", volume_db, max_dist)


func play_ambient_3d(name_key: String, parent: Node, position: Vector3, volume_db: float = 0.0, loop: bool = true, max_dist: float = 18.0) -> AudioStreamPlayer3D:
	var stream := _stream(AMBIENCE.get(name_key, ""))
	if stream == null:
		return null
	var p := _spawn_3d(stream, parent, position, "Ambience", volume_db, max_dist)
	if loop and p != null and p.stream is AudioStreamOggVorbis:
		# loop by restarting on finish
		p.finished.connect(func():
			if is_instance_valid(p):
				p.play())
	return p


func play_footstep(parent: Node, position: Vector3, surface: String, loudness: float = 0.0) -> void:
	var list: Array = STEPS.get(surface, STEPS["wood"])
	var path: String = list[randi() % list.size()]
	var stream := _stream(path)
	if stream == null:
		return
	var p := _spawn_3d(stream, parent, position, "SFX", linear_to_db(clampf(loudness, 0.05, 1.0)), 20.0)
	if p != null:
		p.max_distance = 20.0


func _spawn_3d(stream: AudioStream, parent: Node, position: Vector3, bus: String, volume_db: float, max_dist: float) -> AudioStreamPlayer3D:
	if parent == null or not parent.is_inside_tree():
		return null
	var p := AudioStreamPlayer3D.new()
	p.stream = stream
	p.bus = bus
	p.volume_db = volume_db
	p.max_distance = max_dist
	p.unit_size = 6.0
	p.attenuation_filter_cutoff_hz = 18000
	parent.add_child(p)
	p.global_position = position
	p.finished.connect(p.queue_free)
	p.play()
	return p


func set_ui_root(root: Node) -> void:
	_ui_root = root


func ui_click() -> void:
	play_sfx("ui_click", -6.0)


func ui_hover() -> void:
	play_sfx("ui_hover", -10.0)


func ui_back() -> void:
	play_sfx("ui_back", -6.0)
