extends Node
## InventoryManager: items, slots, combine rules, persistence-friendly state.

signal picked(item_id: String)
signal removed(item_id: String)

const MAX_SLOTS := 10

# item_id -> {name_key, desc_key, icon: String(color+letter), stackable}
const ITEMS := {
	"flashlight": {"name_key": "item.flashlight.name", "desc_key": "item.flashlight.desc", "color": Color(0.85, 0.75, 0.4), "letter": "F", "stackable": false},
	"key_nursery": {"name_key": "item.key_nursery.name", "desc_key": "item.key_nursery.desc", "color": Color(0.8, 0.62, 0.25), "letter": "K", "stackable": false},
	"key_basement": {"name_key": "item.key_basement.name", "desc_key": "item.key_basement.desc", "color": Color(0.62, 0.66, 0.7), "letter": "K", "stackable": false},
	"fuse": {"name_key": "item.fuse.name", "desc_key": "item.fuse.desc", "color": Color(0.3, 0.65, 0.75), "letter": "E", "stackable": false},
	"fuel": {"name_key": "item.fuel.name", "desc_key": "item.fuel.desc", "color": Color(0.75, 0.45, 0.15), "letter": "C", "stackable": false},
	"gear": {"name_key": "item.gear.name", "desc_key": "item.gear.desc", "color": Color(0.62, 0.58, 0.5), "letter": "G", "stackable": true},
	"battery": {"name_key": "item.battery.name", "desc_key": "item.battery.desc", "color": Color(0.35, 0.5, 0.4), "letter": "B", "stackable": true},
}

# combine pairs -> result + consumed inputs
const COMBINE_RULES := [
	{"inputs": ["flashlight", "battery"], "result": "flashlight_charged", "consumes_battery": true},
]

var items: Array[String] = []


func reset() -> void:
	items.clear()
	EventBus.inventory_changed.emit()


func add_item(item_id: String) -> bool:
	if not ITEMS.has(item_id):
		push_warning("Inventory: unknown item " + item_id)
		return false
	if items.size() >= MAX_SLOTS:
		return false
	items.append(item_id)
	picked.emit(item_id)
	EventBus.inventory_changed.emit()
	return true


func remove_item(item_id: String, count: int = 1) -> void:
	for i in count:
		items.erase(item_id)
	removed.emit(item_id)
	EventBus.inventory_changed.emit()


func has_item(item_id: String, count: int = 1) -> bool:
	return items.count(item_id) >= count


func count_item(item_id: String) -> int:
	return items.count(item_id)


func get_item_name(item_id: String) -> String:
	var def: Dictionary = ITEMS.get(item_id, {})
	return Localization.tr_key(def.get("name_key", item_id))


func get_item_desc(item_id: String) -> String:
	var def: Dictionary = ITEMS.get(item_id, {})
	return Localization.tr_key(def.get("desc_key", ""))


func try_combine(a: String, b: String) -> String:
	for rule in COMBINE_RULES:
		var inputs: Array = rule["inputs"]
		var pair_match := (a in inputs and b in inputs)
		if not pair_match:
			continue
		if a == b:
			continue
		var result: String = rule["result"]
		if result == "flashlight_charged":
			# battery consumed, flashlight recharged
			if has_item("flashlight") and has_item("battery"):
				remove_item("battery", 1)
				Game.flashlight_charged()
				EventBus.item_combined.emit("flashlight_charged")
				return "flashlight_charged"
	return ""


func serialize() -> Array:
	return items.duplicate()


func deserialize(arr: Array) -> void:
	items.clear()
	for it in arr:
		if ITEMS.has(it):
			items.append(it)
	EventBus.inventory_changed.emit()
