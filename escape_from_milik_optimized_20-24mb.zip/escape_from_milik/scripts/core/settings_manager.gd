extends Node
## SettingsManager: loads/applies/persists all user settings.

signal settings_changed

const SAVE_PATH := "user://settings.cfg"

const QUALITY_PRESETS := {
        "low": {"msaa": 0, "shadows": 0, "bloom": false, "ssao": false, "fog": false, "draw_distance": 40.0, "dust": false, "shadow_lights": 0},
        "medium": {"msaa": 1, "shadows": 1, "bloom": true, "ssao": false, "fog": true, "draw_distance": 60.0, "dust": true, "shadow_lights": 1},
        "high": {"msaa": 1, "shadows": 1, "bloom": true, "ssao": true, "fog": true, "draw_distance": 80.0, "dust": true, "shadow_lights": 2},
        "ultra": {"msaa": 2, "shadows": 2, "bloom": true, "ssao": true, "fog": true, "draw_distance": 110.0, "dust": true, "shadow_lights": 3},
}

var quality: String = "medium"
var shadow_quality: int = 1
var draw_distance: float = 60.0
var antialiasing: bool = true
var bloom: bool = true
var ssao: bool = false
var fog_effects: bool = true

var vol_master: float = 1.0
var vol_music: float = 0.8
var vol_sfx: float = 1.0
var vol_monster: float = 1.0
var vol_ambient: float = 0.9

var sensitivity: float = 1.0
var joystick_size: float = 1.0
var button_opacity: float = 0.75
var invert_y: bool = false

var language: String = "ru"
var vibration: bool = true
var subtitles: bool = true
var hints: bool = true
var fps_limit: int = 60


func _ready() -> void:
        load_settings()
        apply_all()


func load_settings() -> void:
        var cfg := ConfigFile.new()
        if cfg.load(SAVE_PATH) != OK:
                return
        quality = cfg.get_value("graphics", "quality", quality)
        shadow_quality = cfg.get_value("graphics", "shadow_quality", shadow_quality)
        draw_distance = cfg.get_value("graphics", "draw_distance", draw_distance)
        antialiasing = cfg.get_value("graphics", "antialiasing", antialiasing)
        bloom = cfg.get_value("graphics", "bloom", bloom)
        ssao = cfg.get_value("graphics", "ssao", ssao)
        fog_effects = cfg.get_value("graphics", "fog", fog_effects)
        vol_master = cfg.get_value("audio", "master", vol_master)
        vol_music = cfg.get_value("audio", "music", vol_music)
        vol_sfx = cfg.get_value("audio", "sfx", vol_sfx)
        vol_monster = cfg.get_value("audio", "monster", vol_monster)
        vol_ambient = cfg.get_value("audio", "ambient", vol_ambient)
        sensitivity = cfg.get_value("controls", "sensitivity", sensitivity)
        joystick_size = cfg.get_value("controls", "joystick_size", joystick_size)
        button_opacity = cfg.get_value("controls", "button_opacity", button_opacity)
        invert_y = cfg.get_value("controls", "invert_y", invert_y)
        language = cfg.get_value("game", "language", language)
        vibration = cfg.get_value("game", "vibration", vibration)
        subtitles = cfg.get_value("game", "subtitles", subtitles)
        hints = cfg.get_value("game", "hints", hints)
        fps_limit = cfg.get_value("game", "fps_limit", fps_limit)
        Localization.set_language(language)


func save_settings() -> void:
        var cfg := ConfigFile.new()
        cfg.set_value("graphics", "quality", quality)
        cfg.set_value("graphics", "shadow_quality", shadow_quality)
        cfg.set_value("graphics", "draw_distance", draw_distance)
        cfg.set_value("graphics", "antialiasing", antialiasing)
        cfg.set_value("graphics", "bloom", bloom)
        cfg.set_value("graphics", "ssao", ssao)
        cfg.set_value("graphics", "fog", fog_effects)
        cfg.set_value("audio", "master", vol_master)
        cfg.set_value("audio", "music", vol_music)
        cfg.set_value("audio", "sfx", vol_sfx)
        cfg.set_value("audio", "monster", vol_monster)
        cfg.set_value("audio", "ambient", vol_ambient)
        cfg.set_value("controls", "sensitivity", sensitivity)
        cfg.set_value("controls", "joystick_size", joystick_size)
        cfg.set_value("controls", "button_opacity", button_opacity)
        cfg.set_value("controls", "invert_y", invert_y)
        cfg.set_value("game", "language", language)
        cfg.set_value("game", "vibration", vibration)
        cfg.set_value("game", "subtitles", subtitles)
        cfg.set_value("game", "hints", hints)
        cfg.set_value("game", "fps_limit", fps_limit)
        cfg.save(SAVE_PATH)


func apply_all() -> void:
        _apply_audio()
        _apply_fps()
        var preset: Dictionary = QUALITY_PRESETS.get(quality, QUALITY_PRESETS["medium"])
        msaa_level = int(preset["msaa"])
        shadow_quality = int(preset["shadows"])
        draw_distance = float(preset["draw_distance"])
        bloom = bool(preset["bloom"])
        ssao = bool(preset["ssao"])
        fog_effects = bool(preset["fog"])
        Localization.set_language(language)
        settings_changed.emit()


var msaa_level: int = 1


func set_quality(q: String) -> void:
        quality = q
        apply_all()


func _apply_audio() -> void:
        var bus_master := AudioServer.get_bus_index("Master")
        AudioServer.set_bus_volume_db(bus_master, linear_to_db(clampf(vol_master, 0.0001, 1.0)))
        for pair in [["Music", vol_music], ["SFX", vol_sfx], ["Monster", vol_monster], ["Ambience", vol_ambient]]:
                var idx := AudioServer.get_bus_index(pair[0])
                if idx >= 0:
                        AudioServer.set_bus_volume_db(idx, linear_to_db(clampf(pair[1], 0.0001, 1.0)))


func _apply_fps() -> void:
        if fps_limit > 0:
                Engine.max_fps = fps_limit
        else:
                Engine.max_fps = 0


func vibrate(duration_ms: int = 60, strength: float = 0.6) -> void:
        if vibration:
                Input.vibrate_handheld(duration_ms, strength)


func reset_to_defaults() -> void:
        quality = "medium"
        shadow_quality = 1
        draw_distance = 60.0
        antialiasing = true
        bloom = true
        ssao = false
        fog_effects = true
        vol_master = 1.0
        vol_music = 0.8
        vol_sfx = 1.0
        vol_monster = 1.0
        vol_ambient = 0.9
        sensitivity = 1.0
        joystick_size = 1.0
        button_opacity = 0.75
        invert_y = false
        language = "ru"
        vibration = true
        subtitles = true
        hints = true
        fps_limit = 60
        apply_all()
        save_settings()
