extends Node
## DifficultyManager: difficulty presets affecting AI, puzzles and hints.

signal difficulty_changed

const DIFFICULTIES := {
	"easy": {
		"id": "easy",
		"monster_speed_walk": 1.35,
		"monster_speed_chase": 2.5,
		"vision_range": 9.0,
		"vision_fov_deg": 70.0,
		"hearing_multiplier": 0.6,
		"search_time": 10.0,
		"search_points": 2,
		"hide_check_chance": 0.15,
		"respawn_to_yard": false,
		"puzzle_code_length": 3,
		"show_symbol_hints": true,
		"hint_notes_enabled": true,
		"chase_give_up_time": 6.0,
		"attack_range": 1.3,
		"patrol_points_count": 5,
	},
	"normal": {
		"id": "normal",
		"monster_speed_walk": 1.8,
		"monster_speed_chase": 3.1,
		"vision_range": 12.0,
		"vision_fov_deg": 85.0,
		"hearing_multiplier": 1.0,
		"search_time": 14.0,
		"search_points": 3,
		"hide_check_chance": 0.3,
		"respawn_to_yard": false,
		"puzzle_code_length": 3,
		"show_symbol_hints": true,
		"hint_notes_enabled": true,
		"chase_give_up_time": 8.0,
		"attack_range": 1.4,
		"patrol_points_count": 6,
	},
	"hard": {
		"id": "hard",
		"monster_speed_walk": 2.2,
		"monster_speed_chase": 3.7,
		"vision_range": 15.0,
		"vision_fov_deg": 100.0,
		"hearing_multiplier": 1.5,
		"search_time": 18.0,
		"search_points": 4,
		"hide_check_chance": 0.5,
		"respawn_to_yard": false,
		"puzzle_code_length": 3,
		"show_symbol_hints": false,
		"hint_notes_enabled": false,
		"chase_give_up_time": 10.0,
		"attack_range": 1.5,
		"patrol_points_count": 7,
	},
	"nightmare": {
		"id": "nightmare",
		"monster_speed_walk": 2.6,
		"monster_speed_chase": 4.3,
		"vision_range": 18.0,
		"vision_fov_deg": 115.0,
		"hearing_multiplier": 2.2,
		"search_time": 24.0,
		"search_points": 5,
		"hide_check_chance": 0.75,
		"respawn_to_yard": true,
		"puzzle_code_length": 3,
		"show_symbol_hints": false,
		"hint_notes_enabled": false,
		"chase_give_up_time": 14.0,
		"attack_range": 1.6,
		"patrol_points_count": 8,
	},
}

var current: String = "normal"


func set_difficulty(d: String) -> void:
	if DIFFICULTIES.has(d):
		current = d
		difficulty_changed.emit()


func param(key: String) -> Variant:
	var preset: Dictionary = DIFFICULTIES.get(current, DIFFICULTIES["normal"])
	return preset.get(key)


func preset() -> Dictionary:
	return DIFFICULTIES.get(current, DIFFICULTIES["normal"])


func display_name() -> String:
	return Localization.tr_key("diff.%s.name" % current)


func is_active() -> bool:
	return Game.is_playing
