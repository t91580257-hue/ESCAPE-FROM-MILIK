extends Node
## UIManager: HUD messages, subtitles, note reader, vignette/scare overlay, puzzle UIs.

var message_label: Label = null
var subtitle_label: Label = null
var objective_label: Label = null
var hud_root: Control = null
var _msg_tween: Tween = null
var _sub_tween: Tween = null


func register_hud(hud: Control) -> void:
	hud_root = hud
	message_label = hud.get_node_or_null("MessageLabel")
	subtitle_label = hud.get_node_or_null("SubtitleLabel")
	objective_label = hud.get_node_or_null("ObjectiveLabel")


func show_message(text: String, duration: float = 3.0) -> void:
	if message_label == null:
		return
	message_label.text = text
	message_label.modulate.a = 0.0
	message_label.visible = true
	if _msg_tween != null and _msg_tween.is_valid():
		_msg_tween.kill()
	_msg_tween = create_tween()
	_msg_tween.tween_property(message_label, "modulate:a", 1.0, 0.25)
	_msg_tween.tween_interval(duration)
	_msg_tween.tween_property(message_label, "modulate:a", 0.0, 0.5)
	_msg_tween.tween_callback(func(): message_label.visible = false)


func show_subtitle(text: String, duration: float = 3.5) -> void:
	if not SettingsManager.subtitles:
		return
	if subtitle_label == null:
		return
	subtitle_label.text = text
	subtitle_label.modulate.a = 0.0
	subtitle_label.visible = true
	if _sub_tween != null and _sub_tween.is_valid():
		_sub_tween.kill()
	_sub_tween = create_tween()
	_sub_tween.tween_property(subtitle_label, "modulate:a", 1.0, 0.3)
	_sub_tween.tween_interval(duration)
	_sub_tween.tween_property(subtitle_label, "modulate:a", 0.0, 0.6)
	_sub_tween.tween_callback(func(): subtitle_label.visible = false)


func set_objective(text: String) -> void:
	if objective_label == null:
		return
	objective_label.text = text
	objective_label.visible = text != ""


func vignette_pulse(strength: float = 0.5, duration: float = 0.8) -> void:
	var vp := get_viewport()
	if vp == null:
		return
	var overlay := _get_or_create_scare_overlay()
	overlay.modulate = Color(1, 1, 1, 0)
	create_tween().tween_property(overlay, "modulate:a", strength, 0.08)
	var tw := create_tween()
	tw.tween_interval(duration * 0.4)
	tw.tween_property(overlay, "modulate:a", 0.0, duration * 0.6)


func _get_or_create_scare_overlay() -> Control:
	var root := get_tree().current_scene
	if root == null:
		return Control.new()
	var existing := root.get_node_or_null("ScareOverlay")
	if existing != null:
		return existing
	var overlay := ColorRect.new()
	overlay.name = "ScareOverlay"
	overlay.color = Color(0.25, 0.0, 0.0, 0.55)
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.modulate = Color(1, 1, 1, 0)
	root.add_child(overlay)
	return overlay
