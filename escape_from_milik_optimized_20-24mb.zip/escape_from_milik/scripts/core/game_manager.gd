extends Node
## GameManager: current run state, story flags, stats, win/lose flow, checkpoints.

const PUZZLE_TOTAL := 6

var is_playing: bool = false
var difficulty: String = "normal"
var story_flags: Dictionary = {}
var puzzles_solved: Array[String] = []
var items_collected_total: int = 0
var times_caught: int = 0
var run_time: float = 0.0
var checkpoint_id: String = ""
var power_on: bool = false
var flashlight_battery: float = 1.0
var flashlight_unlocked: bool = false
var monster_active: bool = false
var aggression_stage: int = 0  # 0 calm (yard/intro), 1 patrol, 2 hunter, 3 final
var pending_load: bool = false
var pending_load_payload: Dictionary = {}

signal state_dirty


func _ready() -> void:
        process_mode = Node.PROCESS_MODE_ALWAYS
        EventBus.puzzle_solved.connect(_on_puzzle_solved)
        EventBus.item_picked.connect(_on_item_picked)


func _process(delta: float) -> void:
        if is_playing and not get_tree().paused:
                run_time += delta


func start_new_game(diff: String) -> void:
        difficulty = diff
        DifficultyManager.set_difficulty(diff)
        _reset_run()
        is_playing = true
        EventBus.game_started.emit(diff)


func _reset_run() -> void:
        story_flags.clear()
        puzzles_solved.clear()
        items_collected_total = 0
        times_caught = 0
        run_time = 0.0
        checkpoint_id = "yard"
        power_on = false
        flashlight_battery = 1.0
        flashlight_unlocked = false
        monster_active = false
        aggression_stage = 0
        InventoryManager.reset()


func load_state(data: Dictionary) -> void:
        difficulty = data.get("difficulty", "normal")
        DifficultyManager.set_difficulty(difficulty)
        story_flags = data.get("story_flags", {})
        var pl: Array = data.get("puzzles_solved", [])
        puzzles_solved.clear()
        for p in pl:
                puzzles_solved.append(str(p))
        items_collected_total = int(data.get("items_collected", 0))
        times_caught = int(data.get("times_caught", 0))
        run_time = float(data.get("run_time", 0.0))
        checkpoint_id = data.get("checkpoint", "yard")
        power_on = bool(data.get("power_on", false))
        flashlight_battery = float(data.get("flashlight_battery", 1.0))
        flashlight_unlocked = bool(data.get("flashlight_unlocked", false))
        monster_active = bool(data.get("monster_active", false))
        aggression_stage = int(data.get("aggression_stage", 0))
        InventoryManager.deserialize(data.get("inventory", []))
        is_playing = true


func serialize_state() -> Dictionary:
        return {
                "difficulty": difficulty,
                "story_flags": story_flags,
                "puzzles_solved": puzzles_solved,
                "items_collected": items_collected_total,
                "times_caught": times_caught,
                "run_time": run_time,
                "checkpoint": checkpoint_id,
                "power_on": power_on,
                "flashlight_battery": flashlight_battery,
                "flashlight_unlocked": flashlight_unlocked,
                "monster_active": monster_active,
                "aggression_stage": aggression_stage,
                "inventory": InventoryManager.serialize(),
        }


func set_flag(flag: String) -> void:
        story_flags[flag] = true
        EventBus.story_flag_set.emit(flag)
        state_dirty.emit()


func has_flag(flag: String) -> bool:
        return story_flags.get(flag, false)


func register_checkpoint(id: String) -> void:
        checkpoint_id = id
        EventBus.checkpoint_reached.emit(id)


func autosave(slot_data: Dictionary = {}) -> void:
        var payload := serialize_state()
        payload["player"] = slot_data.get("player", {})
        payload["world"] = slot_data.get("world", {})
        SaveManager.write_save(payload)


func flashlight_charged() -> void:
        flashlight_battery = 1.0
        state_dirty.emit()


func _on_puzzle_solved(id: String) -> void:
        if not puzzles_solved.has(id):
                puzzles_solved.append(id)


func _on_item_picked(_id: String) -> void:
        items_collected_total += 1


func win_game() -> void:
        if not is_playing:
                return
        is_playing = false
        var stats := {
                "time": format_time(run_time),
                "time_sec": run_time,
                "items": items_collected_total,
                "puzzles": puzzles_solved.size(),
                "deaths": times_caught,
                "difficulty": difficulty,
        }
        EventBus.game_won.emit(stats)
        AudioManager.stop_music(1.0)
        AudioManager.play_sfx("victory_stinger")


func lose_game() -> void:
        if not is_playing:
                return
        times_caught += 1
        EventBus.player_caught.emit()


func format_time(sec: float) -> String:
        var s := int(sec)
        return "%02d:%02d" % [s / 60, s % 60]


func set_power(on: bool) -> void:
        power_on = on
        EventBus.power_changed.emit(on)


func raise_aggression(stage: int) -> void:
        if stage > aggression_stage:
                aggression_stage = stage
                monster_active = stage >= 1
                state_dirty.emit()
