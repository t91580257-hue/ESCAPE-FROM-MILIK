extends Node
## Localization: RU / EN text dictionaries. Key-based lookup, falls back to RU.

const LANG_RU := "ru"
const LANG_EN := "en"

var language: String = LANG_RU

# Strings[key] = {ru: "...", en: "..."}
const STRINGS := {
        # ---------- Main menu ----------
        "game.title": {"ru": "УБЕГИ ОТ МИЛИКА", "en": "ESCAPE FROM MILIK"},
        "menu.new_game": {"ru": "НОВАЯ ИГРА", "en": "NEW GAME"},
        "menu.continue": {"ru": "ПРОДОЛЖИТЬ", "en": "CONTINUE"},
        "menu.continue_disabled": {"ru": "ПРОДОЛЖИТЬ (НЕТ СОХРАНЕНИЙ)", "en": "CONTINUE (NO SAVE)"},
        "menu.difficulty": {"ru": "ВЫБОР УРОВНЯ", "en": "DIFFICULTY"},
        "menu.settings": {"ru": "НАСТРОЙКИ", "en": "SETTINGS"},
        "menu.about": {"ru": "ОБ ИГРЕ", "en": "ABOUT"},
        "menu.exit": {"ru": "ВЫХОД", "en": "EXIT"},
        "menu.back": {"ru": "НАЗАД", "en": "BACK"},
        "menu.apply": {"ru": "ПРИМЕНИТЬ", "en": "APPLY"},
        "menu.reset": {"ru": "СБРОСИТЬ", "en": "RESET"},
        "menu.retry": {"ru": "ПОВТОРИТЬ", "en": "RETRY"},
        "menu.play_again": {"ru": "ИГРАТЬ СНОВА", "en": "PLAY AGAIN"},
        "menu.restart": {"ru": "ПЕРЕЗАПУСТИТЬ", "en": "RESTART"},
        "menu.resume": {"ru": "ПРОДОЛЖИТЬ", "en": "RESUME"},
        "menu.to_main_menu": {"ru": "В ГЛАВНОЕ МЕНЮ", "en": "MAIN MENU"},

        # ---------- Difficulty ----------
        "diff.title": {"ru": "ВЫБОР СЛОЖНОСТИ", "en": "CHOOSE DIFFICULTY"},
        "diff.easy.name": {"ru": "ЛЁГКИЙ", "en": "EASY"},
        "diff.easy.desc": {"ru": "Медленный Милик, слабый слух и зрение, много подсказок.", "en": "Slow Milik, poor hearing and vision, many hints."},
        "diff.normal.name": {"ru": "НОРМАЛЬНЫЙ", "en": "NORMAL"},
        "diff.normal.desc": {"ru": "Сбалансированный монстр и стандартные головоломки.", "en": "Balanced monster and standard puzzles."},
        "diff.hard.name": {"ru": "СЛОЖНЫЙ", "en": "HARD"},
        "diff.hard.desc": {"ru": "Быстрый и внимательный Милик, сложные загадки.", "en": "Fast and alert Milik, harder puzzles."},
        "diff.nightmare.name": {"ru": "КОШМАР", "en": "NIGHTMARE"},
        "diff.nightmare.desc": {"ru": "Максимальная агрессия, минимум подсказок. Он слышит всё.", "en": "Maximum aggression, almost no hints. He hears everything."},

        # ---------- Settings ----------
        "set.title": {"ru": "НАСТРОЙКИ", "en": "SETTINGS"},
        "set.graphics": {"ru": "ГРАФИКА", "en": "GRAPHICS"},
        "set.quality": {"ru": "Качество", "en": "Quality"},
        "set.texture_quality": {"ru": "Качество текстур", "en": "Texture quality"},
        "set.shadow_quality": {"ru": "Качество теней", "en": "Shadow quality"},
        "set.draw_distance": {"ru": "Дальность прорисовки", "en": "Draw distance"},
        "set.antialiasing": {"ru": "Сглаживание", "en": "Anti-aliasing"},
        "set.bloom": {"ru": "Bloom", "en": "Bloom"},
        "set.ssao": {"ru": "SSAO", "en": "SSAO"},
        "set.fog": {"ru": "Объёмный туман", "en": "Volumetric fog"},
        "set.fps_limit": {"ru": "Ограничение FPS", "en": "FPS limit"},
        "set.audio": {"ru": "ЗВУК", "en": "AUDIO"},
        "set.vol_master": {"ru": "Общая громкость", "en": "Master volume"},
        "set.vol_music": {"ru": "Музыка", "en": "Music"},
        "set.vol_sfx": {"ru": "Эффекты", "en": "Effects"},
        "set.vol_monster": {"ru": "Монстр", "en": "Monster"},
        "set.vol_ambient": {"ru": "Окружение", "en": "Ambience"},
        "set.controls": {"ru": "УПРАВЛЕНИЕ", "en": "CONTROLS"},
        "set.sensitivity": {"ru": "Чувствительность камеры", "en": "Camera sensitivity"},
        "set.joystick_size": {"ru": "Размер джойстика", "en": "Joystick size"},
        "set.button_opacity": {"ru": "Прозрачность кнопок", "en": "Button opacity"},
        "set.invert_y": {"ru": "Инверсия камеры", "en": "Invert camera Y"},
        "set.gameplay": {"ru": "ИГРА", "en": "GAMEPLAY"},
        "set.language": {"ru": "Язык", "en": "Language"},
        "set.vibration": {"ru": "Вибрация", "en": "Vibration"},
        "set.subtitles": {"ru": "Субтитры", "en": "Subtitles"},
        "set.hints": {"ru": "Подсказки", "en": "Hints"},
        "set.on": {"ru": "Вкл", "en": "On"},
        "set.off": {"ru": "Выкл", "en": "Off"},
        "set.applied": {"ru": "Настройки применены", "en": "Settings applied"},
        "set.low": {"ru": "Низкая", "en": "Low"},
        "set.medium": {"ru": "Средняя", "en": "Medium"},
        "set.high": {"ru": "Высокая", "en": "High"},
        "set.ultra": {"ru": "Ультра", "en": "Ultra"},
        "set.fps30": {"ru": "30 FPS", "en": "30 FPS"},
        "set.fps60": {"ru": "60 FPS", "en": "60 FPS"},
        "set.fps120": {"ru": "120 FPS", "en": "120 FPS"},
        "set.nolimit": {"ru": "Без ограничения", "en": "Unlimited"},

        # ---------- About ----------
        "about.title": {"ru": "ОБ ИГРЕ", "en": "ABOUT"},
        "about.text": {"ru": "«УБЕГИ ОТ МИЛИКА» — атмосферный 3D-хоррор.\n\nВы гуляли со своим плюшевым другом Миликом, когда старый дом у двора затянул его внутрь. Внутри живёт его злая копия. Найдите ключи, решите загадки, включите генератор и освободите настоящего Милика из клетки.\n\nНе шумите. Он слышит.\n\nУправление: джойстик слева — движение, свайп справа — камера, кнопки справа — действия.", "en": "'ESCAPE FROM MILIK' is an atmospheric 3D horror.\n\nYou were walking with your plush friend Milik when the old house pulled him inside. An evil copy lives there now. Find the keys, solve the puzzles, start the generator and free the real Milik from the cage.\n\nDo not make noise. He listens.\n\nControls: left stick to move, right swipe to look, action buttons on the right."},

        # ---------- Loading ----------
        "load.title": {"ru": "ЗАГРУЗКА…", "en": "LOADING…"},
        "load.tip1": {"ru": "Совет: бег создаёт много шума. Милик слышит далеко.", "en": "Tip: sprinting is loud. Milik hears it far away."},
        "load.tip2": {"ru": "Совет: прячьтесь в шкафу, если он рядом.", "en": "Tip: hide in the wardrobe when he is near."},
        "load.tip3": {"ru": "Совет: фонарик выдаёт вас в темноте. Выключайте его вовремя.", "en": "Tip: your flashlight gives you away. Switch it off in time."},
        "load.tip4": {"ru": "Совет: записки в доме содержат подсказки к замкам.", "en": "Tip: notes in the house hold clues to the locks."},
        "load.tip5": {"ru": "Совет: приседайте, чтобы двигаться тише.", "en": "Tip: crouch to move silently."},

        # ---------- HUD ----------
        "hud.interact": {"ru": "ВЗАИМОДЕЙСТВОВАТЬ", "en": "INTERACT"},
        "hud.run": {"ru": "БЕГ", "en": "RUN"},
        "hud.crouch": {"ru": "ПРИСЕСТЬ", "en": "CROUCH"},
        "hud.pickup": {"ru": "ПОДОБРАТЬ", "en": "PICK UP"},
        "hud.open": {"ru": "ОТКРЫТЬ", "en": "OPEN"},
        "hud.locked": {"ru": "ЗАПЕРТО", "en": "LOCKED"},
        "hud.read": {"ru": "ЧИТАТЬ", "en": "READ"},
        "hud.hide": {"ru": "СПРЯТАТЬСЯ", "en": "HIDE"},
        "hud.leave": {"ru": "ВЫЙТИ", "en": "LEAVE"},
        "hud.paused": {"ru": "ПАУЗА", "en": "PAUSED"},
        "hud.inventory": {"ru": "ИНВЕНТАРЬ", "en": "INVENTORY"},
        "hud.empty_slot": {"ru": "Пусто", "en": "Empty"},
        "hud.use": {"ru": "ИСПОЛЬЗОВАТЬ", "en": "USE"},
        "hud.combine": {"ru": "СОЕДИНИТЬ", "en": "COMBINE"},
        "hud.close": {"ru": "ЗАКРЫТЬ", "en": "CLOSE"},
        "hud.combined": {"ru": "Предметы соединены!", "en": "Items combined!"},
        "hud.cannot_combine": {"ru": "Эти предметы нельзя соединить.", "en": "These items cannot be combined."},
        "hud.objective": {"ru": "ЦЕЛЬ", "en": "OBJECTIVE"},

        # ---------- Items ----------
        "item.flashlight.name": {"ru": "Фонарик", "en": "Flashlight"},
        "item.flashlight.desc": {"ru": "Старый фонарик. Освещает путь, но выдаёт вас в темноте.", "en": "An old flashlight. Lights the way but gives you away."},
        "item.key_nursery.name": {"ru": "Ключ от детской", "en": "Nursery key"},
        "item.key_nursery.desc": {"ru": "Медный ключ из шкафа в гостиной.", "en": "A brass key from the living room cabinet."},
        "item.key_basement.name": {"ru": "Ключ от подвала", "en": "Basement key"},
        "item.key_basement.desc": {"ru": "Тяжёлый ключ из сундука в кладовой.", "en": "A heavy key from the pantry chest."},
        "item.fuse.name": {"ru": "Электронный блок", "en": "Fuse module"},
        "item.fuse.desc": {"ru": "Деталь для генератора в подвале.", "en": "A part needed for the basement generator."},
        "item.fuel.name": {"ru": "Канистра с топливом", "en": "Fuel canister"},
        "item.fuel.desc": {"ru": "Топливо для генератора.", "en": "Fuel for the generator."},
        "item.gear.name": {"ru": "Шестерёнка", "en": "Gear"},
        "item.gear.desc": {"ru": "Механизм для замка клетки. Нужно три.", "en": "A gear for the cage lock. Three are needed."},
        "item.battery.name": {"ru": "Батарея для фонаря", "en": "Lantern battery"},
        "item.battery.desc": {"ru": "Заряжает фонарик. Соедините с фонариком в инвентаре.", "en": "Recharges the flashlight. Combine with the flashlight."},
        "item.note.name": {"ru": "Записка", "en": "Note"},

        # ---------- Puzzles / world ----------
        "world.front_door": {"ru": "Дверь дома", "en": "House door"},
        "world.locked_door": {"ru": "Заперто. Нужен ключ.", "en": "Locked. A key is needed."},
        "world.locked_nursery": {"ru": "Заперто. Нужен ключ от детской.", "en": "Locked. The nursery key is needed."},
        "world.locked_basement": {"ru": "Заперто. Нужен ключ от подвала.", "en": "Locked. The basement key is needed."},
        "world.keypad_hint": {"ru": "Кодовый замок", "en": "Keypad lock"},
        "world.symbol_cabinet": {"ru": "Шкаф с символами", "en": "Symbol cabinet"},
        "world.symbol_hint": {"ru": "Нажимайте символы в порядке комнат.", "en": "Press symbols in the order of the rooms."},
        "world.generator": {"ru": "Генератор", "en": "Generator"},
        "world.generator_need_fuel": {"ru": "Нет топлива.", "en": "No fuel."},
        "world.generator_need_fuse": {"ru": "Нет электронного блока.", "en": "No fuse module."},
        "world.generator_ready": {"ru": "Запустить генератор?", "en": "Start the generator?"},
        "world.generator_on": {"ru": "Генератор работает!", "en": "The generator is running!"},
        "world.breaker": {"ru": "Щиток переключателей", "en": "Breaker panel"},
        "world.breaker_hint": {"ru": "Порядок переключателей написан в записке.", "en": "The switch order is written in a note."},
        "world.cage_gate": {"ru": "Механизм клетки", "en": "Cage mechanism"},
        "world.cage_need_gears": {"ru": "Не хватает шестерёнок: %d из %d.", "en": "Not enough gears: %d of %d."},
        "world.cage_crank": {"ru": "Крутить механизм", "en": "Turn the mechanism"},
        "world.cage_opening": {"ru": "Механизм открывает клетку…", "en": "The mechanism opens the cage…"},
        "world.hide_spot": {"ru": "Укрытие", "en": "Hiding spot"},
        "world.door_opened": {"ru": "Дверь скрипнула…", "en": "The door creaked…"},
        "world.power_on": {"ru": "Включилось электричество!", "en": "The power is on!"},
	"world.generator_need_power": {"ru": "Нет питания. Запустите генератор.", "en": "No power. Start the generator."},
	"world.cage_no_power": {"ru": "Механизм обесточен. Нужно питание.", "en": "The mechanism has no power."},
	"world.cage_gear_installed": {"ru": "Шестерёнки: %d/3", "en": "Gears: %d/3"},
	"puzzle.cabinet_solved": {"ru": "Шкаф открыт! Внутри ключ от детской.", "en": "The cabinet is open! A nursery key is inside."},
	"puzzle.breaker_solved": {"ru": "Питание на механизм клетки подано!", "en": "Power routed to the cage mechanism!"},
	"puzzle.breaker_wrong": {"ru": "Неверный порядок. Рычаги сброшены.", "en": "Wrong order. Levers reset."},
	"objective.walk_house": {"ru": "Погуляйте с Миликом и подойдите к дому", "en": "Walk with Milik and approach the house"},
	"objective.enter_house": {"ru": "Войдите в дом и найдите Милика", "en": "Enter the house and find Milik"},
	"objective.find_milik": {"ru": "Ищите Милика. Осмотрите комнаты, соберите подсказки", "en": "Search for Milik. Explore rooms, gather clues"},
	"objective.find_breaker": {"ru": "Найдите щиток в подвале", "en": "Find the breaker panel in the basement"},
	"objective.fix_cage": {"ru": "Откройте клетку: 3 шестерёнки и механизм", "en": "Open the cage: 3 gears and the mechanism"},
	"objective.cage_room": {"ru": "Милик где-то здесь… Откройте клетку", "en": "Milik is somewhere here… Open the cage"},
        "world.saved": {"ru": "Сохранено", "en": "Saved"},

        # ---------- Notes ----------
        "note.1.title": {"ru": "Записка Милика", "en": "Milik's note"},
        "note.1.text": {"ru": "«Он пришел из тени и утащил меня вниз… Запиши: шкаф в гостиной открывают СИМВОЛЫ. Осмотри картины в комнатах».", "en": "'It came from the shadow and dragged me down… Note: the living room cabinet opens with SYMBOLS. Look at the paintings in the rooms.'"},
	"note.2.title": {"ru": "Дневник хозяина", "en": "Owner's diary"},
	"note.2.text": {"ru": "«Детская заперта. Ключ от неё — в шкафу с символами в гостиной. В кладовой на кухне я спрятал всё нужное. Код от кладовой я вывесил на доске в детской».", "en": "'The nursery is locked. Its key is in the living room symbol cabinet. I hid everything in the kitchen pantry. The pantry code is written on the nursery blackboard.'"},
	"note.3.title": {"ru": "Мелкая записка", "en": "Crayon note"},
	"note.3.text": {"ru": "«Порядок символов на шкафу: ПРИХОЖАЯ, ГОСТИНАЯ, КУХНЯ, КОРИДОР».", "en": "'Symbol order on the cabinet: ENTRY HALL, LIVING ROOM, KITCHEN, CORRIDOR.'"},
	"note.4.title": {"ru": "Инструкция щитка", "en": "Breaker manual"},
	"note.4.text": {"ru": "«После генератора щиток подаст питание на клетку. Порядок рычагов: 2, 1, 3».", "en": "'After the generator, the breaker routes power to the cage. Lever order: 2, 1, 3.'"},
	"note.5.title": {"ru": "Записка механика", "en": "Mechanic's note"},
	"note.5.text": {"ru": "«Клетка открывается тремя шестерёнками. Одна в детской, одна в кладовой, одна на верстаке. И щиток: 2-1-3».", "en": "'The cage opens with three gears. One in the nursery, one in the pantry, one on the workbench. And the breaker: 2-1-3.'"},
	"note.6.title": {"ru": "Дневник, поздний", "en": "Diary, late entry"},
	"note.6.text": {"ru": "«Оно выглядит как игрушка… но глаза светятся. Оно охотится на звук. Прячьтесь в шкафах. Бегать нельзя».", "en": "'It looks like a toy… but its eyes glow. It hunts by sound. Hide in the wardrobes. Never run.'"},

        # ---------- Story ----------
        "story.intro_1": {"ru": "Мы гуляли со Миликом…", "en": "Milik and I were walking…"},
        "story.intro_2": {"ru": "Милик: «Какой странный дом…»", "en": "Milik: 'What a strange house…'"},
        "story.intro_3": {"ru": "Что происходит?!", "en": "What is happening?!"},
        "story.intro_4": {"ru": "МИЛИК! НЕТ!", "en": "MILIK! NO!"},
        "story.enter_house": {"ru": "Я должен войти и спасти его.", "en": "I have to go in and save him."},
        "story.first_sight": {"ru": "Это… Милик? Что с тобой сделали?", "en": "Is that… Milik? What have they done to you?"},
        "story.rescue_1": {"ru": "Милик! Я здесь!", "en": "Milik! I'm here!"},
        "story.rescue_2": {"ru": "Милик: «Ты пришёл за мной!»", "en": "Milik: 'You came for me!'"},
        "story.final_scare": {"ru": "ЗА КАМИ! БЕГИ!", "en": "BEHIND US! RUN!"},
        "story.power_note": {"ru": "Свет включён. Теперь он видит дальше…", "en": "The lights are on. Now he sees farther…"},

        # ---------- Endings ----------
        "win.title": {"ru": "ТЫ СПАС МИЛИКА!", "en": "YOU SAVED MILIK!"},
        "win.time": {"ru": "Время прохождения: %s", "en": "Time: %s"},
        "win.items": {"ru": "Найдено предметов: %d", "en": "Items found: %d"},
        "win.puzzles": {"ru": "Решено загадок: %d", "en": "Puzzles solved: %d"},
        "win.deaths": {"ru": "Пойман раз: %d", "en": "Times caught: %d"},
        "lose.title": {"ru": "ОН ПОЙМАЛ ТЕБЯ…", "en": "HE CAUGHT YOU…"},
        "lose.hint": {"ru": "Попробуй снова. И на этот раз — тише.", "en": "Try again. And this time — quieter."},
}


func set_language(lang: String) -> void:
        language = lang if lang in [LANG_RU, LANG_EN] else LANG_RU


func tr_key(key: String, args: Array = []) -> String:
        var entry: Variant = STRINGS.get(key, null)
        var text: String = ""
        if entry == null:
                text = key
        else:
                text = entry.get(language, entry.get(LANG_RU, key))
        if args.size() > 0:
                text = text % args
        return text


func tr_num(key: String, args: Array = []) -> String:
        return tr_key(key, args)
