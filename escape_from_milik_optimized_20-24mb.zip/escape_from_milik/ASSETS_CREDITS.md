# Авторы и лицензии ресурсов

## Модели Милика (главные персонажи)
- `models/characters/milik_friendly.glb`, `milik_evil.glb`, `milik_toy.glb`
- Источник: модели, предоставленные автором игры (пользовательские GLB).
  Оптимизированы: 300+ частей слиты в 14–16 меш-групп, сгенерированы нормали,
  анимации Walk_Loop / Angry_Shake_Loop перенесены в horror-версию.

## Мебель и пропсы — Poly Haven (https://polyhaven.com), лицензия CC0
ArmChair_01, Barrel_01/02, ClassicNightstand_01, CoffeeTable_01, GothicBed_01,
GothicCabinet_01, Lantern_01, mantel_clock_01, metal_office_desk, metal_toolbox,
metal_tool_chest, bench_vice_01, modular_industrial_pipes_01, modular_electric_cables,
portable_generator, Rockingchair_01, SchoolChair_01, SchoolDesk_01, Sofa_01,
Television_01, vintage_electric_kettle, vintage_flashlight, vintage_grandfather_clock_01,
vintage_microwave, vintage_oil_lamp, vintage_radio_transceiver, vintage_suitcase,
wicker_basket_01, wine_bottles_01, wooden_bookshelf_worn, wooden_broom, wooden_bucket_01,
wooden_crate_01/02, chinese_cabinet, chinese_commode, chinese_console_table,
dining_table, dining_chair_02, drawer_cabinet, electric_stove, hanging_picture_frame_01-03,
hanging_industrial_lamp, industrial_caged_sconce, industrial_storage_cart,
industrial_wall_sconce, ornate_mirror_01, bull_head, fire_alarm, lightbulb_01,
mantel_clock_01, throw_pillows_01, treasure_chest, rubber_duck_toy, alarm_clock_01,
brass_pan_01, brass_pot_01/02, ceramic_pot, circuit_board, pastic_torch_6v,
flathead_screwdriver, screwdriver, cross_pein_hammer, adjustable_wrench,
pot_enamel_01, propane_tank, cardboard_box_01, medical_box, wall_clock.

## Текстуры PBR — Poly Haven, CC0
damaged_plaster, grey_plaster_02, peeling_painted_wall, blue/red_plaster_weathered,
weathered_plank_siding, weathered_planks, wood_peeling_paint_weathered, brick_wall_001,
old_wood_floor, dirty_concrete, dirty_tiles, dirt_floor, rustic_stone_wall,
rusty_metal, metal_grate_rusty, dirty_carpet, painted_concrete.

## Модели окружения — OpenGameArt.org, CC0
- «Modular Dungeon — 3D Models» (cell walls, gateway, lever, switch, pedestal,
  steps, rail): https://opengameart.org/content/modular-dungeon-3d-models (CC0).
  Переэкспортированы в GLB с текстурами Poly Haven (CC0).
- «Gear Pack» (шестерёнки): https://opengameart.org/content/gear-pack (CC0).

## Шрифты
- DejaVu Sans (Bold/Book) — лицензия Bitstream Vera/DejaVu (свободное
  распространение разрешено). Файлы: `ui/fonts/font_main.ttf`, `font_regular.ttf`.

## Аудио
Вся музыка и звуковые эффекты синтезированы программно (numpy → OGG Vorbis)
специально для этой игры и не требуют внешних лицензий.

## Код
GDScript-код проекта — MIT License.
